// ─────────────────────────────────────────────────────────────────────────────
// ChatBox — collapsible glassmorphism chat panel.
// Messages ride the WebRTC DataChannel as signed envelopes (zero relay, zero
// storage — pure P2P). Outbound sends pass through a token bucket; inbound
// floods are dropped by the store. React escapes all output — no XSS surface.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '../../store/useGameStore';
import { CHAT_MAX_LENGTH } from '../../lib/protocol';
import { shortAddress } from '../../types';

function MessageBubble({ self, text, at }: { self: boolean; text: string; at: number }): React.JSX.Element {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 380, damping: 26 }}
      className={`flex ${self ? 'justify-end' : 'justify-start'}`}
    >
      <div
        className={`max-w-[82%] rounded-xl px-3 py-2 text-[13px] leading-snug ${
          self
            ? 'rounded-br-sm border border-xenon-cyan/30 bg-xenon-cyan/10 text-xenon-ice'
            : 'rounded-bl-sm border border-xenon-magenta/30 bg-xenon-magenta/10 text-xenon-pink'
        }`}
      >
        <div className="break-words">{text}</div>
        <div className="mt-0.5 text-right font-mono text-[9px] text-white/30">
          {new Date(at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </motion.div>
  );
}

export default function ChatBox(): React.JSX.Element {
  const chat = useGameStore((s) => s.chat);
  const chatOpen = useGameStore((s) => s.chatOpen);
  const unread = useGameStore((s) => s.unread);
  const chatLimitedAt = useGameStore((s) => s.chatLimitedAt);
  const peer = useGameStore((s) => s.peer);
  const netStatus = useGameStore((s) => s.netStatus);
  const phase = useGameStore((s) => s.phase);
  const setChatOpen = useGameStore((s) => s.setChatOpen);
  const sendChat = useGameStore((s) => s.sendChat);
  const armoryOpen = useGameStore((s) => s.armoryOpen);

  // While the mobile armory tray is expanded it owns the bottom strip — the
  // chat tab/panel lifts above it instead of overlapping. When the match ends
  // the end-overlay is modal, so the floating tab hides and the panel closes.
  const liftForArmory = phase === 'ACTIVE' && armoryOpen;
  const endOverlayUp = phase === 'FINISHED' || phase === 'ABORTED';
  useEffect(() => {
    if (endOverlayUp && chatOpen) setChatOpen(false);
  }, [endOverlayUp, chatOpen, setChatOpen]);

  const [draft, setDraft] = useState('');
  const [limitedFlash, setLimitedFlash] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const enabled = netStatus === 'connected' && (phase === 'ACTIVE' || phase === 'FINISHED');

  // Auto-scroll to the newest message whenever history grows or panel opens.
  useEffect(() => {
    const node = scrollRef.current;
    if (node && chatOpen) node.scrollTop = node.scrollHeight;
  }, [chat.length, chatOpen]);

  // Transient "slow down" flash when the outbound bucket rejects a send.
  useEffect(() => {
    if (!chatLimitedAt) return;
    setLimitedFlash(true);
    const timer = window.setTimeout(() => setLimitedFlash(false), 1400);
    return () => window.clearTimeout(timer);
  }, [chatLimitedAt]);

  const submit = async (): Promise<void> => {
    const text = draft.trim();
    if (!text || !enabled) return;
    const sent = await sendChat(text);
    if (sent) setDraft('');
  };

  return (
    <>
      {/* collapsed tab */}
      <AnimatePresence>
        {!chatOpen && !endOverlayUp && (
          <motion.button
            key="chat-tab"
            type="button"
            initial={{ opacity: 0, x: -24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            onClick={() => setChatOpen(true)}
            className={`glass absolute left-[max(1rem,env(safe-area-inset-left))] z-30 flex items-center gap-2 px-4 py-2.5 font-display text-[11px] font-bold tracking-[0.2em] text-xenon-cyan transition hover:border-xenon-cyan/60 ${
              liftForArmory
                ? 'bottom-[calc(max(1rem,env(safe-area-inset-bottom))+9rem)] sm:bottom-[max(1rem,env(safe-area-inset-bottom))]'
                : 'bottom-[max(1rem,env(safe-area-inset-bottom))]'
            }`}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" className="h-4 w-4">
              <path d="M21 12a8 8 0 0 1-8 8H5l-2 2V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8Z" strokeLinejoin="round" />
            </svg>
            LINK
            {unread > 0 && (
              <motion.span
                key={unread}
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-xenon-magenta px-1 font-mono text-[10px] font-bold text-white shadow-neon-m"
              >
                {unread > 9 ? '9+' : unread}
              </motion.span>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* expanded panel */}
      <AnimatePresence>
        {chatOpen && (
          <motion.aside
            key="chat-panel"
            initial={{ opacity: 0, x: -48, scale: 0.96 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -48, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className={`glass absolute left-[max(1rem,env(safe-area-inset-left))] z-30 flex h-[min(380px,55dvh)] w-[min(300px,86vw)] flex-col overflow-hidden ${
              liftForArmory
                ? 'bottom-[calc(max(1rem,env(safe-area-inset-bottom))+9rem)] sm:bottom-[max(1rem,env(safe-area-inset-bottom))]'
                : 'bottom-[max(1rem,env(safe-area-inset-bottom))]'
            }`}
          >
            {/* header */}
            <div className="flex items-center justify-between border-b border-white/10 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    enabled ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]' : 'bg-white/25'
                  }`}
                />
                <span className="font-display text-[10px] font-bold tracking-[0.25em] text-white/85">
                  SECURE LINK
                </span>
                <span className="font-mono text-[9px] text-ghost">
                  {peer ? shortAddress(peer.address) : '—'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setChatOpen(false)}
                className="rounded p-1 text-ghost transition hover:bg-white/10 hover:text-white"
                aria-label="Collapse chat"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-3.5 w-3.5">
                  <path d="m6 6 12 12M18 6 6 18" strokeLinecap="round" />
                </svg>
              </button>
            </div>

            {/* history */}
            <div ref={scrollRef} className="chat-scroll flex-1 space-y-2 overflow-y-auto px-3 py-2.5">
              {chat.length === 0 && (
                <div className="mt-10 text-center font-mono text-[10px] leading-relaxed text-ghost/70">
                  channel open · end-to-end signed
                  <br />
                  no servers touch these words
                </div>
              )}
              {chat.map((message) => (
                <MessageBubble key={message.id} self={message.self} text={message.text} at={message.at} />
              ))}
            </div>

            {/* composer */}
            <div className="border-t border-white/10 p-2">
              <AnimatePresence>
                {limitedFlash && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-1 text-center font-mono text-[9px] tracking-[0.25em] text-xenon-amber"
                  >
                    RATE LIMITED — BREATHE
                  </motion.div>
                )}
              </AnimatePresence>
              <div className="flex items-center gap-1.5">
                <input
                  value={draft}
                  onChange={(event) => setDraft(event.target.value.slice(0, CHAT_MAX_LENGTH))}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' && !event.shiftKey) {
                      event.preventDefault();
                      void submit();
                    }
                  }}
                  disabled={!enabled}
                  placeholder={enabled ? 'transmit…' : 'link offline'}
                  maxLength={CHAT_MAX_LENGTH}
                  className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-[13px] text-white placeholder:text-ghost/50 outline-none transition focus:border-xenon-cyan/50 disabled:opacity-40"
                />
                <button
                  type="button"
                  onClick={() => void submit()}
                  disabled={!enabled || draft.trim().length === 0}
                  className="rounded-lg border border-xenon-cyan/40 bg-xenon-cyan/15 p-2 text-xenon-cyan transition hover:bg-xenon-cyan/30 disabled:cursor-not-allowed disabled:opacity-30"
                  aria-label="Send message"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-4 w-4">
                    <path d="m3 11 18-8-8 18-2.5-7.5L3 11Z" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
