// ─────────────────────────────────────────────────────────────────────────────
// XenonBoard — the holographic 3×3 arena.
// React Three Fiber scene: floating glass slabs wrapped in a neon rail frame,
// a shader-driven sonar floor, light-tube X/O marks, superposition shimmer,
// GPU-only particle bursts, win beam, and impulse screen shake.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import { Float, Sparkles, Stars } from '@react-three/drei';
import { a, useSpring } from '@react-spring/three';
import { useGameStore } from '../../store/useGameStore';
import { CELL_COL, CELL_ROW, type CellState, type FxImpulse, type Mark } from '../../types';
import holoGridVert from '../../shaders/holoGrid.vert';
import holoGridFrag from '../../shaders/holoGrid.frag';
import neonTubeVert from '../../shaders/neonTube.vert';
import neonTubeFrag from '../../shaders/neonTube.frag';
import particlesVert from '../../shaders/particles.vert';
import particlesFrag from '../../shaders/particles.frag';

const SPACING = 2.3;
const BOARD_Y = 0.62;
const CYAN = new THREE.Color('#00f0ff');
const MAGENTA = new THREE.Color('#ff2bd6');
const AMBER = new THREE.Color('#ffc857');
const VIOLET = new THREE.Color('#7b2bff');
const WHITE_HOT = new THREE.Color('#eaffff');

export const markColor = (mark: Mark): THREE.Color => (mark === 'X' ? CYAN : MAGENTA);

const cellPosition = (index: number): [number, number, number] => [
  (CELL_COL(index) - 1) * SPACING,
  BOARD_Y,
  (CELL_ROW(index) - 1) * SPACING,
];

// ── Shader material plumbing ─────────────────────────────────────────────────

// Every live material with a uTime uniform registers here; one useFrame drives all.
const timedMaterials = new Set<THREE.ShaderMaterial>();

function useTimedMaterial<T extends THREE.ShaderMaterial>(material: T): T {
  useEffect(() => {
    timedMaterials.add(material);
    return () => {
      timedMaterials.delete(material);
      material.dispose();
    };
  }, [material]);
  return material;
}

const makeNeonTubeMaterial = (
  colorA: THREE.Color,
  colorB: THREE.Color,
  options: { quantum?: boolean; intensity?: number; seed?: number } = {},
): THREE.ShaderMaterial =>
  new THREE.ShaderMaterial({
    vertexShader: neonTubeVert,
    fragmentShader: neonTubeFrag,
    transparent: true,
    depthWrite: true,
    uniforms: {
      uTime: { value: 0 },
      uColorA: { value: colorA.clone() },
      uColorB: { value: colorB.clone() },
      uBirth: { value: 0 },
      uIntensity: { value: options.intensity ?? 1.2 },
      uQuantum: { value: options.quantum ? 1 : 0 },
      uSeed: { value: options.seed ?? Math.random() * 100 },
    },
  });

/** Birth flash: drives uBirth 0 → 1 shortly after mount. */
function useBirth(material: THREE.ShaderMaterial, duration = 0.35): void {
  const bornAt = useRef<number | null>(null);
  useFrame(({ clock }) => {
    if (bornAt.current === null) bornAt.current = clock.elapsedTime;
    const t = (clock.elapsedTime - bornAt.current) / duration;
    material.uniforms.uBirth.value = Math.min(1, t);
  });
}

// ── Marks ────────────────────────────────────────────────────────────────────

function XMark({ color }: { color: THREE.Color }): React.JSX.Element {
  const material = useTimedMaterial(useMemo(() => makeNeonTubeMaterial(color, WHITE_HOT), [color]));
  useBirth(material);
  const { scale } = useSpring({ scale: 1, from: { scale: 0 }, config: { tension: 280, friction: 15 } });
  return (
    <a.group scale={scale}>
      {[Math.PI / 4, -Math.PI / 4].map((angle) => (
        <group key={angle} rotation={[0, angle, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} material={material}>
            <capsuleGeometry args={[0.09, 1.15, 4, 14]} />
          </mesh>
        </group>
      ))}
    </a.group>
  );
}

function OMark({ color }: { color: THREE.Color }): React.JSX.Element {
  const material = useTimedMaterial(useMemo(() => makeNeonTubeMaterial(color, WHITE_HOT), [color]));
  useBirth(material);
  const { scale } = useSpring({ scale: 1, from: { scale: 0 }, config: { tension: 280, friction: 15 } });
  return (
    <a.group scale={scale} rotation={[Math.PI / 2, 0, 0]}>
      <mesh material={material}>
        <torusGeometry args={[0.52, 0.09, 16, 56]} />
      </mesh>
    </a.group>
  );
}

/** A superposed tile: both glyphs overlap, identity oscillating in-shader. */
function QuantumMark(): React.JSX.Element {
  const group = useRef<THREE.Group>(null);
  const material = useTimedMaterial(
    useMemo(() => makeNeonTubeMaterial(CYAN, MAGENTA, { quantum: true, intensity: 1.5 }), []),
  );
  useBirth(material, 0.5);
  useFrame(({ clock }) => {
    if (group.current) {
      group.current.rotation.y = clock.elapsedTime * 0.9;
      group.current.position.y = BOARD_Y + 0.12 + Math.sin(clock.elapsedTime * 2.2) * 0.07;
    }
  });
  return (
    <group ref={group}>
      {[Math.PI / 4, -Math.PI / 4].map((angle) => (
        <group key={angle} rotation={[0, angle, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} material={material}>
            <capsuleGeometry args={[0.07, 1.0, 4, 12]} />
          </mesh>
        </group>
      ))}
      <mesh rotation={[Math.PI / 2, 0, 0]} material={material}>
        <torusGeometry args={[0.42, 0.07, 14, 48]} />
      </mesh>
      {/* containment ring marking the tile as unresolved */}
      <mesh rotation={[Math.PI / 2, 0, 0]} material={material} position={[0, -0.1, 0]}>
        <torusGeometry args={[0.82, 0.02, 8, 64]} />
      </mesh>
    </group>
  );
}

function ShieldRing(): React.JSX.Element {
  const material = useTimedMaterial(
    useMemo(() => makeNeonTubeMaterial(AMBER, WHITE_HOT, { intensity: 1.1 }), []),
  );
  useBirth(material, 0.6);
  useFrame(({ clock }) => {
    material.uniforms.uIntensity.value = 1.1 + Math.sin(clock.elapsedTime * 4) * 0.45;
  });
  return (
    <mesh rotation={[Math.PI / 2, 0, 0]} material={material} position={[0, -0.18, 0]}>
      <torusGeometry args={[0.78, 0.028, 10, 64]} />
    </mesh>
  );
}

// ── Cells ────────────────────────────────────────────────────────────────────

function Cell({
  index,
  cell,
  hovered,
  setHovered,
}: {
  index: number;
  cell: CellState;
  hovered: boolean;
  setHovered: (index: number | null) => void;
}): React.JSX.Element {
  const handleCellClick = useGameStore((s) => s.handleCellClick);
  const turn = useGameStore((s) => s.turn);
  const position = cellPosition(index);

  const { scale } = useSpring({
    scale: hovered ? 1.05 : 1,
    config: { tension: 320, friction: 20 },
  });

  const frameMaterial = useTimedMaterial(
    useMemo(
      () =>
        makeNeonTubeMaterial(markColor(turn), VIOLET, {
          intensity: hovered ? 1.6 : 0.45,
          seed: index * 3.7,
        }),
      // Color follows the live turn; intensity is handled imperatively below.
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [index],
    ),
  );
  useEffect(() => {
    (frameMaterial.uniforms.uColorA.value as THREE.Color).copy(markColor(turn));
  }, [frameMaterial, turn]);
  useEffect(() => {
    frameMaterial.uniforms.uIntensity.value = hovered ? 1.6 : 0.45;
  }, [frameMaterial, hovered]);

  const onPointerDown = (event: ThreeEvent<PointerEvent>): void => {
    event.stopPropagation();
    void handleCellClick(index);
  };

  return (
    <a.group position={position} scale={scale}>
      {/* glass slab */}
      <mesh
        position={[0, -BOARD_Y + 0.06, 0]}
        onPointerDown={onPointerDown}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHovered(index);
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          setHovered(null);
          document.body.style.cursor = 'auto';
        }}
      >
        <boxGeometry args={[2.0, 0.1, 2.0]} />
        <meshPhysicalMaterial
          color="#0b132a"
          transparent
          opacity={hovered ? 0.52 : 0.34}
          roughness={0.12}
          metalness={0.25}
          clearcoat={0.9}
          clearcoatRoughness={0.25}
        />
      </mesh>
      {/* neon edge rails */}
      {(
        [
          [0, 0, 1.0, 2.0, 0.05, 0.05],
          [0, 0, -1.0, 2.0, 0.05, 0.05],
          [1.0, 0, 0, 0.05, 0.05, 2.0],
          [-1.0, 0, 0, 0.05, 0.05, 2.0],
        ] as const
      ).map(([x, y, z, w, h, d], i) => (
        <mesh key={i} position={[x, -BOARD_Y + 0.13 + y, z]} material={frameMaterial}>
          <boxGeometry args={[w, h, d]} />
        </mesh>
      ))}
      {/* occupancy layer */}
      {cell.kind === 'mark' && cell.mark === 'X' && <XMark color={CYAN} />}
      {cell.kind === 'mark' && cell.mark === 'O' && <OMark color={MAGENTA} />}
      {cell.kind === 'mark' && cell.shielded && <ShieldRing />}
      {cell.kind === 'quantum' && <QuantumMark />}
    </a.group>
  );
}

// ── Particle bursts (GPU-driven; CPU only tracks lifetimes) ──────────────────

const BURST_COUNT = 220;

function ParticleBurst({
  position,
  colorA,
  colorB,
  onDone,
}: {
  position: [number, number, number];
  colorA: THREE.Color;
  colorB: THREE.Color;
  onDone: () => void;
}): React.JSX.Element {
  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(BURST_COUNT * 3);
    const seeds = new Float32Array(BURST_COUNT * 4);
    for (let i = 0; i < BURST_COUNT; i += 1) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      seeds[i * 4] = Math.sin(phi) * Math.cos(theta);
      seeds[i * 4 + 1] = Math.abs(Math.cos(phi)) * 0.9 + 0.1; // bias upward
      seeds[i * 4 + 2] = Math.sin(phi) * Math.sin(theta);
      seeds[i * 4 + 3] = 0.35 + Math.random() * 0.65;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 4));
    return geo;
  }, []);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: particlesVert,
        fragmentShader: particlesFrag,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        uniforms: {
          uAge: { value: 0 },
          uLife: { value: 1.5 },
          uSpread: { value: 2.6 },
          uPointScale: { value: 26 * Math.min(window.devicePixelRatio, 2) },
          uColorA: { value: colorA.clone() },
          uColorB: { value: colorB.clone() },
        },
      }),
    [colorA, colorB],
  );

  const bornAt = useRef<number | null>(null);
  const done = useRef(false);
  useFrame(({ clock }) => {
    if (bornAt.current === null) bornAt.current = clock.elapsedTime;
    const age = clock.elapsedTime - bornAt.current;
    material.uniforms.uAge.value = age;
    if (age > material.uniforms.uLife.value && !done.current) {
      done.current = true;
      onDone();
    }
  });

  useEffect(
    () => () => {
      geometry.dispose();
      material.dispose();
    },
    [geometry, material],
  );

  return <points position={position} geometry={geometry} material={material} frustumCulled={false} />;
}

// ── Win beam ─────────────────────────────────────────────────────────────────

function WinBeam({ line, winner }: { line: number[]; winner: Mark }): React.JSX.Element {
  const [from, , to] = line;
  const aPos = new THREE.Vector3(...cellPosition(from));
  const bPos = new THREE.Vector3(...cellPosition(to));
  const { midpoint, length, quaternion } = useMemo(() => {
    const direction = bPos.clone().sub(aPos);
    const len = direction.length();
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      direction.clone().normalize(),
    );
    return { midpoint: aPos.clone().add(bPos).multiplyScalar(0.5), length: len, quaternion: quat };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from, to]);
  const color = markColor(winner);
  const material = useTimedMaterial(
    useMemo(() => makeNeonTubeMaterial(color, WHITE_HOT, { intensity: 2.4 }), [color]),
  );
  useBirth(material, 0.6);
  return (
    <mesh position={midpoint} quaternion={quaternion} material={material}>
      <cylinderGeometry args={[0.05, 0.05, length + 1.2, 12]} />
    </mesh>
  );
}

// ── Holo floor ───────────────────────────────────────────────────────────────

function HoloFloor(): React.JSX.Element {
  const turn = useGameStore((s) => s.turn);
  const material = useTimedMaterial(
    useMemo(
      () =>
        new THREE.ShaderMaterial({
          vertexShader: holoGridVert,
          fragmentShader: holoGridFrag,
          transparent: true,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
          uniforms: {
            uTime: { value: 0 },
            uColorA: { value: CYAN.clone() },
            uColorB: { value: VIOLET.clone() },
            uOpacity: { value: 0.85 },
          },
        }),
      [],
    ),
  );
  useEffect(() => {
    (material.uniforms.uColorA.value as THREE.Color).copy(markColor(turn));
  }, [material, turn]);
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]} material={material}>
      <planeGeometry args={[30, 30, 1, 1]} />
    </mesh>
  );
}

// ── Frame + rig ──────────────────────────────────────────────────────────────

function OuterFrame(): React.JSX.Element {
  const material = useTimedMaterial(
    useMemo(() => makeNeonTubeMaterial(CYAN, MAGENTA, { intensity: 0.9 }), []),
  );
  const half = SPACING * 1.5 + 0.15;
  const length = half * 2 + 0.1;
  return (
    <group position={[0, 0.02, 0]}>
      {(
        [
          [0, 0, half, length, 0.07, 0.1],
          [0, 0, -half, length, 0.07, 0.1],
          [half, 0, 0, 0.1, 0.07, length],
          [-half, 0, 0, 0.1, 0.07, length],
        ] as const
      ).map(([x, y, z, w, h, d], i) => (
        <mesh key={i} position={[x, y, z]} material={material}>
          <boxGeometry args={[w, h, d]} />
        </mesh>
      ))}
      {/* corner power nodes */}
      {(
        [
          [half, half],
          [half, -half],
          [-half, half],
          [-half, -half],
        ] as const
      ).map(([x, z], i) => (
        <mesh key={i} position={[x, 0.06, z]} material={material}>
          <sphereGeometry args={[0.11, 16, 16]} />
        </mesh>
      ))}
    </group>
  );
}

interface BurstRecord {
  id: number;
  position: [number, number, number];
  colorA: THREE.Color;
  colorB: THREE.Color;
}

/** Screen shake + burst spawner, both driven by store FX impulses. */
function FxRig({ children }: { children: React.ReactNode }): React.JSX.Element {
  const rig = useRef<THREE.Group>(null);
  const amplitude = useRef(0);
  const [bursts, setBursts] = useState<BurstRecord[]>([]);
  const lastNonce = useRef(0);

  useEffect(
    () =>
      useGameStore.subscribe((state) => {
        const fx: FxImpulse = state.fx;
        if (fx.nonce === lastNonce.current) return;
        lastNonce.current = fx.nonce;
        const shake: Record<string, number> = {
          place: 0.07,
          explode: 0.4,
          shield: 0.05,
          hack: 0.32,
          dilation: 0.12,
          collapse: 0.22,
          win: 0.55,
          chat: 0,
          error: 0.04,
        };
        amplitude.current = Math.max(amplitude.current, shake[fx.kind] ?? 0);
        if (fx.cell >= 0 && ['place', 'explode', 'hack', 'collapse', 'win'].includes(fx.kind)) {
          const cellState = state.board[fx.cell];
          const color =
            cellState?.kind === 'mark'
              ? markColor(cellState.mark)
              : cellState?.kind === 'quantum'
                ? markColor(cellState.owner)
                : CYAN;
          const record: BurstRecord = {
            id: fx.nonce,
            position: cellPosition(fx.cell),
            colorA: color,
            colorB: WHITE_HOT,
          };
          setBursts((list) => [...list.slice(-8), record]);
        }
      }),
    [],
  );

  useFrame((_, delta) => {
    amplitude.current *= Math.exp(-5.5 * delta);
    if (rig.current) {
      const amp = amplitude.current;
      rig.current.position.set(
        (Math.random() - 0.5) * amp,
        (Math.random() - 0.5) * amp * 0.6,
        (Math.random() - 0.5) * amp,
      );
    }
  });

  return (
    <>
      <group ref={rig}>{children}</group>
      {bursts.map((burst) => (
        <ParticleBurst
          key={burst.id}
          position={burst.position}
          colorA={burst.colorA}
          colorB={burst.colorB}
          onDone={() => setBursts((list) => list.filter((b) => b.id !== burst.id))}
        />
      ))}
    </>
  );
}

/** Ambient light rig tinted by whose turn it is. */
function TurnLight(): React.JSX.Element {
  const light = useRef<THREE.PointLight>(null);
  const turn = useGameStore((s) => s.turn);
  const winner = useGameStore((s) => s.winner);
  useFrame(({ clock }) => {
    if (!light.current) return;
    const target = winner && winner.winner !== 'DRAW' ? markColor(winner.winner) : markColor(turn);
    light.current.color.lerp(target, 0.08);
    light.current.intensity = 46 + Math.sin(clock.elapsedTime * 2.6) * 9;
  });
  return <pointLight ref={light} position={[0, 6.5, 0]} intensity={46} distance={26} decay={2} />;
}

// ── Scene ────────────────────────────────────────────────────────────────────

function Scene(): React.JSX.Element {
  const board = useGameStore((s) => s.board);
  const winner = useGameStore((s) => s.winner);
  const [hovered, setHovered] = useState<number | null>(null);

  // One clock loop feeds every registered shader's uTime uniform.
  useFrame(({ clock }) => {
    timedMaterials.forEach((material) => {
      material.uniforms.uTime.value = clock.elapsedTime;
    });
  });

  return (
    <>
      <color attach="background" args={['#05060f']} />
      <fog attach="fog" args={['#05060f', 14, 34]} />
      <ambientLight intensity={0.32} />
      <pointLight position={[7, 8, 6]} intensity={55} color="#00f0ff" distance={30} decay={2} />
      <pointLight position={[-7, 5, -5]} intensity={40} color="#ff2bd6" distance={30} decay={2} />
      <TurnLight />

      <FxRig>
        <Float speed={1.6} rotationIntensity={0.06} floatIntensity={0.55} floatingRange={[0, 0.16]}>
          <group>
            <OuterFrame />
            {board.map((cell, index) => (
              <Cell
                key={index}
                index={index}
                cell={cell}
                hovered={hovered === index}
                setHovered={setHovered}
              />
            ))}
            {winner?.line && <WinBeam line={winner.line} winner={winner.winner as Mark} />}
          </group>
        </Float>
      </FxRig>

      <HoloFloor />
      <Stars radius={46} depth={24} count={1400} factor={2.4} saturation={0.6} fade speed={0.6} />
      <Sparkles count={70} scale={[15, 7, 15]} position={[0, 2.5, 0]} size={2.2} speed={0.25} color="#7df9ff" />
    </>
  );
}

/**
 * Keeps the whole arena inside the frame on any screen. Phones are portrait
 * (aspect ≈ 0.46), which collapses the horizontal field of view and clips the
 * board's sides — so we widen the FOV and dolly back until the neon frame
 * always fits with margin. Re-runs on every resize / rotation.
 */
function ResponsiveCamera(): null {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    const aspect = size.width / Math.max(1, size.height);
    cam.fov = aspect < 0.9 ? 55 : 42;
    // distance along the view axis needed for the frame's half-width (±4.6u)
    const tanHalfHorizontal = Math.tan(THREE.MathUtils.degToRad(cam.fov / 2)) * aspect;
    const needed = 4.6 / tanHalfHorizontal;
    const base = Math.hypot(7.6, 10.2); // authored desktop framing
    const scale = Math.min(2.4, Math.max(1, needed / base));
    cam.position.set(0, 7.6 * scale, 10.2 * scale);
    cam.updateProjectionMatrix();
    cam.lookAt(0, 0.4, 0);
  }, [camera, size.width, size.height]);
  return null;
}

export default function XenonBoard(): React.JSX.Element {
  return (
    <Canvas
      dpr={[1, 1.75]}
      camera={{ position: [0, 7.6, 10.2], fov: 42 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ camera }) => camera.lookAt(0, 0.4, 0)}
    >
      <ResponsiveCamera />
      <Scene />
    </Canvas>
  );
}
