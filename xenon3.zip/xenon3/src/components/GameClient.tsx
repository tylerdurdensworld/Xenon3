// ─────────────────────────────────────────────────────────────────────────────
// GameClient — root orchestrator (client-only; mounted with ssr:false).
// Wires the WebRTC transport + spatial audio + PWA service worker, then routes:
//   wallet gate → matchmaking lobby → arena (3D board + HUD + chat).
// Layout law: 100dvh everywhere (mobile URL bars), overflow locked, safe-area
// insets respected so notches never eat the HUD.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '../store/useGameStore';
import { useWebRTC } from '../hooks/useWebRTC';
import { useSpatialAudio } from '../hooks/useSpatialAudio';
import ConnectScreen from './ConnectScreen';
import MatchmakingLobby from './lobby/MatchmakingLobby';
import GameHUD from './hud/GameHUD';
import ChatBox from './chat/ChatBox';
import XenonBoard from './three/XenonBoard';

/** CRT scanlines + vignette laid over every screen — pure CSS, zero GPU cost. */
function AtmosphereOverlay(): React.JSX.Element {
  return (
    <>
      <div className="scanlines pointer-events-none fixed inset-0 z-40" />
      <div
        className="pointer-events-none fixed inset-0 z-40"
        style={{ background: 'radial-gradient(ellipse at center, transparent 62%, rgba(2,3,10,0.55) 100%)' }}
      />
    </>
  );
}

/** Registers the PWA service worker once per session (production builds only). */
function useServiceWorker(): void {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') return;
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
    navigator.serviceWorker
      .register('sw.js')
      .catch((error) => console.warn('[xenon3] service worker registration failed:', error));
  }, []);
}

export default function GameClient(): React.JSX.Element {
  useWebRTC();
  useSpatialAudio();
  useServiceWorker();

  const walletStatus = useGameStore((s) => s.walletStatus);
  const phase = useGameStore((s) => s.phase);
  const inMatch = phase === 'ACTIVE' || phase === 'FINISHED' || phase === 'ABORTED';

  return (
    <main className="relative min-h-dvh w-full overflow-hidden bg-void font-body text-white">
      <AtmosphereOverlay />
      {/* No mode="wait": exit animations are rAF-driven, and rAF is FROZEN in
          background tabs — with "wait" a hidden tab never finishes the exit,
          never mounts the next screen, and the match UI deadlocks (this was
          the two-tabs-on-one-laptop stall). Concurrent transitions are
          slightly less pretty for 200ms, but correct in every visibility
          state. */}
      <AnimatePresence>
        {walletStatus !== 'connected' ? (
          <motion.div key="connect" exit={{ opacity: 0, scale: 1.04 }}>
            <ConnectScreen />
          </motion.div>
        ) : inMatch ? (
          <motion.div
            key="arena"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative h-dvh w-full overflow-hidden"
          >
            <div className="absolute inset-0">
              <XenonBoard />
            </div>
            <GameHUD />
            <ChatBox />
          </motion.div>
        ) : (
          <motion.div key="lobby" exit={{ opacity: 0, scale: 0.97 }}>
            <MatchmakingLobby />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
