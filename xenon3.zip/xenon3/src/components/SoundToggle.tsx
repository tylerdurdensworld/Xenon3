// ─────────────────────────────────────────────────────────────────────────────
// SoundToggle — global sound on/off. The flag lives in the game store (and on
// the device); the synth engine follows it through its master gain.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React from 'react';
import { useGameStore } from '../store/useGameStore';

export default function SoundToggle({ className = '' }: { className?: string }): React.JSX.Element {
  const muted = useGameStore((s) => s.muted);
  const toggleMuted = useGameStore((s) => s.toggleMuted);
  return (
    <button
      type="button"
      onClick={toggleMuted}
      aria-label={muted ? 'Unmute sound' : 'Mute sound'}
      title={muted ? 'Sound off — tap to unmute' : 'Sound on — tap to mute'}
      className={`glass px-2 py-1.5 text-ghost transition hover:border-xenon-cyan/60 hover:text-xenon-cyan sm:px-3 sm:py-2 ${className}`}
    >
      {muted ? (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
          <path
            d="M11 5 6 9H3v6h3l5 4V5Zm11 4-5 6m0-6 5 6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
          <path d="M11 5 6 9H3v6h3l5 4V5Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9.5 9.5 0 0 1 0 13" strokeLinecap="round" />
        </svg>
      )}
    </button>
  );
}
