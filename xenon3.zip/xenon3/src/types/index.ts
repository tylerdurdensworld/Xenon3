// ─────────────────────────────────────────────────────────────────────────────
// Xenon3 domain types — shared by the WQD ledger, wire protocol, Zustand store,
// 3D board renderer and HUD. Single source of truth for the game model.
// ─────────────────────────────────────────────────────────────────────────────

export type Mark = 'X' | 'O';

export type PowerUpKind = 'QUANTUM_HACK' | 'NEON_SHIELD' | 'TIME_DILATION' | 'QUANTUM_ENTANGLE';

/**
 * Off-chain WQD price of every power-up, in WQD utility credits.
 * Prices are set at one tenth of the original schedule, so tenth-WQD
 * (0.1) precision is supported throughout the ledger and the HUD.
 */
export const POWER_UP_COST: Record<PowerUpKind, number> = {
  QUANTUM_HACK: 1,
  NEON_SHIELD: 0.5,
  TIME_DILATION: 1.5,
  QUANTUM_ENTANGLE: 0.8,
};

/** Extra burn to collapse your own superposition deterministically onto your mark. */
export const QUANTUM_LOCK_COST = 0.3;

/** Float-safe affordability check — balances are sums of tenth-WQD amounts. */
export const canAfford = (balance: number, cost: number): boolean => balance + 1e-9 >= cost;

/** Compact display for tenth-precision amounts: 0.5 stays "0.5", 1 stays "1". */
export const formatWqd = (amount: number): string => {
  // Deposits carry full 1e-8 precision; trim trailing zeros for display.
  const rounded = Math.round(amount * 1e8) / 1e8;
  if (Number.isInteger(rounded)) return String(rounded);
  return parseFloat(rounded.toFixed(8)).toString();
};

/**
 * Balance readout that never overflows its panel: thousands grouped, decimals
 * shrink as the magnitude grows (≥1000 → 2, ≥100 → 4, else full precision).
 * The exact 1e-8 value stays available via `formatWqd` (tooltips, audits).
 */
export const formatWqdBalance = (amount: number): string => {
  const rounded = Math.round(amount * 1e8) / 1e8;
  const abs = Math.abs(rounded);
  const decimals = abs >= 1000 ? 2 : abs >= 100 ? 4 : 8;
  const grouped = rounded.toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
  return grouped;
};

/** Seconds each player has per turn before the turn is forfeited. */
export const TURN_SECONDS = 30;

/** Milliseconds a Time Dilation freeze adds to the victim's current clock. */
export const DILATION_MS = 20_000;

/** Clock-skew tolerance when validating a peer's TIMEOUT claim. */
export const TIMEOUT_TOLERANCE_MS = 5_000;

export type CellState =
  | { kind: 'empty' }
  | { kind: 'mark'; mark: Mark; shielded: boolean; placedSeq: number }
  | { kind: 'quantum'; owner: Mark; commitment: string; placedSeq: number };

export const EMPTY_CELL: CellState = { kind: 'empty' };

export const emptyBoard = (): CellState[] => Array.from({ length: 9 }, () => ({ ...EMPTY_CELL }));

export type MatchPhase = 'IDLE' | 'CONNECTING' | 'ACTIVE' | 'FINISHED' | 'ABORTED';

export interface PlayerInfo {
  address: string;
  mark: Mark;
}

export interface ChatMessage {
  id: string;
  from: string;
  self: boolean;
  text: string;
  at: number;
  /** Monotonic protocol sequence number — doubles as an anti-replay proof. */
  seq: number;
}

export type FxKind =
  | 'place'
  | 'explode'
  | 'shield'
  | 'hack'
  | 'dilation'
  | 'collapse'
  | 'win'
  | 'defeat'
  | 'stalemate'
  | 'chat'
  | 'error';

export interface FxImpulse {
  /** Changes on every emission so subscribers can react to repeated kinds. */
  nonce: number;
  kind: FxKind;
  /** Board index 0..8 for spatial audio panning, -1 when not cell-bound. */
  cell: number;
}

export interface WinResult {
  winner: Mark | 'DRAW';
  line: number[] | null;
}

export const opponentOf = (mark: Mark): Mark => (mark === 'X' ? 'O' : 'X');

export const shortAddress = (address: string): string =>
  address.length > 10 ? `${address.slice(0, 6)}…${address.slice(-4)}` : address;

/** Stable board index → planar position mapping used by both 3D and audio panning. */
export const CELL_COL = (index: number): number => index % 3;
export const CELL_ROW = (index: number): number => Math.floor(index / 3);
