// Ambient module declarations so TypeScript accepts raw shader imports
// (loaded as strings via the webpack `asset/source` rule in next.config.mjs).
declare module '*.glsl' {
  const source: string;
  export default source;
}
declare module '*.vert' {
  const source: string;
  export default source;
}
declare module '*.frag' {
  const source: string;
  export default source;
}
