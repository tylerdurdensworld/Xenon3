// ─────────────────────────────────────────────────────────────────────────────
// GlobalError — last-resort boundary for root-level render failures.
// The classic trigger on a statically exported PWA is a STALE HTML shell asking
// for hashed chunks a fresh deploy replaced (ChunkLoadError). That case heals
// itself: reload once (guarded, 10s cooldown) to pick up the fresh shell.
// Anything else gets a branded, self-contained fallback (inline styles only —
// the failed chunk may be the one carrying the design system).
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useState } from 'react';

const RELOAD_KEY = 'xenon3:last-auto-reload';
const RELOAD_COOLDOWN_MS = 10_000;

function isChunkLoadFailure(error: Error & { digest?: string }): boolean {
  const haystack = `${error?.name ?? ''} ${error?.message ?? ''} ${error?.digest ?? ''}`;
  return /loading chunk|chunkloaderror|dynamically imported module|failed to fetch/i.test(haystack);
}

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}): React.JSX.Element {
  const [autoReloading, setAutoReloading] = useState(false);

  useEffect(() => {
    if (!isChunkLoadFailure(error)) return;
    try {
      const last = Number(window.sessionStorage.getItem(RELOAD_KEY) ?? 0);
      if (Date.now() - last > RELOAD_COOLDOWN_MS) {
        window.sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
        setAutoReloading(true);
        // Give the render a beat to paint the notice, then hard-reload.
        window.setTimeout(() => window.location.reload(), 600);
      }
    } catch {
      // storage unavailable — fall through to the manual retry UI
    }
  }, [error]);

  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: '100dvh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#02030a',
          color: '#ffffff',
          fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
        }}
      >
        <div style={{ maxWidth: 420, padding: '0 24px', textAlign: 'center' }}>
          <div
            style={{
              fontSize: 28,
              fontWeight: 900,
              letterSpacing: '0.3em',
              color: '#00f0ff',
              userSelect: 'none',
              textShadow: '0 0 24px rgba(0,240,255,0.7)',
            }}
          >
            XENON3
          </div>
          <div style={{ marginTop: 16, fontSize: 12, letterSpacing: '0.2em', color: 'rgba(255,255,255,0.65)' }}>
            {autoReloading ? 'ARENA UPDATED — RECHARGING NEON TUBES…' : 'A NEON TUBE FLICKERED OUT.'}
          </div>
          {!autoReloading && (
            <>
              <div style={{ marginTop: 10, fontSize: 10, lineHeight: 1.7, color: 'rgba(255,255,255,0.4)' }}>
                A fresh build of the arena was just deployed and this tab is holding an older shell.
                One reload syncs you up — your wallet and ledger never leave this device.
              </div>
              <button
                type="button"
                onClick={() => {
                  try {
                    window.sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
                  } catch {
                    /* storage unavailable */
                  }
                  window.location.reload();
                }}
                style={{
                  marginTop: 20,
                  padding: '12px 28px',
                  borderRadius: 10,
                  border: '1px solid rgba(0,240,255,0.5)',
                  background: 'rgba(0,240,255,0.15)',
                  color: '#00f0ff',
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: '0.18em',
                  cursor: 'pointer',
                  fontFamily: 'inherit',
                }}
              >
                RELOAD ARENA
              </button>
              <div style={{ marginTop: 14 }}>
                <button
                  type="button"
                  onClick={reset}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'rgba(255,255,255,0.35)',
                    fontSize: 10,
                    letterSpacing: '0.15em',
                    cursor: 'pointer',
                    textDecoration: 'underline',
                    fontFamily: 'inherit',
                  }}
                >
                  try without reload
                </button>
              </div>
            </>
          )}
        </div>
      </body>
    </html>
  );
}
