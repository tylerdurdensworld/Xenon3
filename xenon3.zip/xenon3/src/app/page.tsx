'use client';

import dynamic from 'next/dynamic';

// The arena is fully client-side (WebGL, WebRTC, wallet APIs) — skip SSR entirely.
const GameClient = dynamic(() => import('../components/GameClient'), {
  ssr: false,
  loading: () => (
    <div className="flex min-h-screen items-center justify-center bg-void">
      <div className="text-center">
        <div
          className="select-none font-display text-3xl font-black tracking-[0.3em] text-xenon-cyan animate-pulse-glow"
          style={{ textShadow: '0 0 24px rgba(0,240,255,0.7)' }}
        >
          XENON3
        </div>
        <div className="mt-3 font-mono text-[10px] tracking-[0.35em] text-ghost">
          CHARGING NEON TUBES…
        </div>
      </div>
    </div>
  ),
});

export default function Page(): React.JSX.Element {
  return <GameClient />;
}
