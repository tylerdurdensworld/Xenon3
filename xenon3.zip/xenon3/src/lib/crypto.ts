// ─────────────────────────────────────────────────────────────────────────────
// Xenon3 cryptographic primitives.
// Every wire message is an EIP-191 signed envelope over a *canonical* JSON body,
// so both peers hash and verify byte-identical payloads. The per-player hash
// chain (prevHash → envelopeHash) makes reordering, drops and replays detectable.
// ─────────────────────────────────────────────────────────────────────────────

import { concat, keccak256, recoverMessageAddress, toBytes, toHex, type Hex } from 'viem';

/** Deterministic JSON: keys sorted recursively, undefined dropped, no whitespace. */
export function canonicalStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    if (typeof value === 'number' && !Number.isFinite(value)) {
      throw new Error('non-finite number in signed payload');
    }
    return JSON.stringify(value) as string;
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => canonicalStringify(item)).join(',')}]`;
  }
  const entries = Object.entries(value as Record<string, unknown>)
    .filter(([, v]) => v !== undefined)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalStringify(v)}`).join(',')}}`;
}

export const hashPayload = (value: unknown): Hex => keccak256(toBytes(canonicalStringify(value)));

export function randomBytes32(): Hex {
  const bytes = new Uint8Array(32);
  globalThis.crypto.getRandomValues(bytes);
  return toHex(bytes);
}

/** Room codes avoid ambiguous glyphs (0/O, 1/I) so they survive voice read-outs. */
export function randomRoomCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(6);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}

export interface MessageSigner {
  signMessage: (args: { message: string }) => Promise<Hex>;
}

/** EIP-191 personal_sign over the canonical payload — independently verifiable by the peer. */
export async function signPayload(signer: MessageSigner, payload: unknown): Promise<Hex> {
  return signer.signMessage({ message: canonicalStringify(payload) });
}

/** Recover the signing address; throws on malformed signatures so callers can cheat-flag. */
export async function recoverPayloadSigner(payload: unknown, signature: Hex): Promise<string> {
  const address = await recoverMessageAddress({ message: canonicalStringify(payload), signature });
  return address.toLowerCase();
}

/** Commitment scheme for Quantum Superposition: commitment = keccak256(secret). */
export const commitSecret = (secret: Hex): Hex => keccak256(secret);

/**
 * Deterministic collapse entropy: keccak256(secret ‖ salt) parity.
 * The owner cannot predict the observer's salt at commit time, and the observer
 * cannot influence the outcome after seeing the commitment — fair coin, no oracle.
 */
export function collapseParity(secret: Hex, salt: Hex): 0 | 1 {
  const digest = keccak256(concat([secret, salt]));
  return BigInt(digest) % 2n === 0n ? 0 : 1;
}
