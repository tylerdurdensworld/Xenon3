// ─────────────────────────────────────────────────────────────────────────────
// Pure Xenon3 rules engine — no React, no I/O. Both peers run identical logic
// over the signed message stream, which is what makes cheating detectable.
// ─────────────────────────────────────────────────────────────────────────────

import type { CellState, Mark, WinResult } from '../types';
import { opponentOf } from '../types';
import { collapseParity, commitSecret } from './crypto';
import type { Hex } from 'viem';

export const WIN_LINES: number[][] = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

/**
 * Winner evaluation. Superposed (quantum) tiles count as NEITHER mark until
 * collapsed — a line through an unresolved tile is not a win yet.
 */
export function evaluateWinner(board: CellState[]): WinResult | null {
  for (const line of WIN_LINES) {
    const [a, b, c] = line;
    const ca = board[a];
    if (ca.kind !== 'mark') continue;
    const cb = board[b];
    const cc = board[c];
    if (cb.kind === 'mark' && cc.kind === 'mark' && cb.mark === ca.mark && cc.mark === ca.mark) {
      return { winner: ca.mark, line };
    }
  }
  const unresolved = board.some((cell) => cell.kind === 'quantum');
  const anyEmpty = board.some((cell) => cell.kind === 'empty');
  if (!unresolved && !anyEmpty) return { winner: 'DRAW', line: null };
  return null;
}

export const isCellPlayable = (board: CellState[], index: number): boolean =>
  index >= 0 && index < 9 && board[index].kind === 'empty';

export const isOwnQuantum = (board: CellState[], index: number, mark: Mark): boolean => {
  const cell = board[index];
  return cell.kind === 'quantum' && cell.owner === mark;
};

export const isPeerQuantum = (board: CellState[], index: number, mark: Mark): boolean => {
  const cell = board[index];
  return cell.kind === 'quantum' && cell.owner === opponentOf(mark);
};

export const isOwnUnshieldedMark = (board: CellState[], index: number, mark: Mark): boolean => {
  const cell = board[index];
  return cell.kind === 'mark' && cell.mark === mark && !cell.shielded;
};

/**
 * Quantum Hack targets the opponent's most recent NORMAL mark that is not
 * protected by a Neon Shield. Superposed tiles are immune (they are not marks).
 * Returns null when there is no legal target — the UI greys the button out.
 */
export function quantumHackTarget(board: CellState[], by: Mark): number | null {
  const enemy = opponentOf(by);
  let target: number | null = null;
  let newest = -1;
  board.forEach((cell, index) => {
    if (cell.kind === 'mark' && cell.mark === enemy && !cell.shielded && cell.placedSeq > newest) {
      newest = cell.placedSeq;
      target = index;
    }
  });
  return target;
}

/** Replace the hacked cell with the attacker's mark; shield never survives a hack. */
export function applyQuantumHack(board: CellState[], by: Mark, target: number): CellState[] {
  return board.map((cell, index) => {
    if (index !== target) return cell;
    const previous = cell as Extract<CellState, { kind: 'mark' }>;
    return { kind: 'mark', mark: by, shielded: false, placedSeq: previous.placedSeq };
  });
}

/**
 * Collapse a superposition. Verifies the revealed secret against the on-board
 * commitment first — a mismatched reveal means the peer fabricated entropy.
 * Parity 0 → owner's mark, parity 1 → observer's mark.
 */
export function collapseQuantum(
  board: CellState[],
  index: number,
  secret: Hex,
  salt: Hex,
): CellState[] {
  const cell = board[index];
  if (cell.kind !== 'quantum') throw new Error(`cell ${index} is not a superposition`);
  if (commitSecret(secret) !== cell.commitment) {
    throw new Error('quantum reveal does not match commitment');
  }
  const outcome = collapseParity(secret, salt);
  const mark: Mark = outcome === 0 ? cell.owner : opponentOf(cell.owner);
  return board.map((c, i) =>
    i === index ? { kind: 'mark', mark, shielded: false, placedSeq: cell.placedSeq } : c,
  );
}

/** Forced decoherence: the owner pays WQD to pin their own superposition to their mark. */
export function lockQuantum(board: CellState[], index: number, secret: Hex): CellState[] {
  const cell = board[index];
  if (cell.kind !== 'quantum') throw new Error(`cell ${index} is not a superposition`);
  if (commitSecret(secret) !== cell.commitment) {
    throw new Error('quantum lock reveal does not match commitment');
  }
  return board.map((c, i) =>
    i === index
      ? { kind: 'mark' as const, mark: cell.owner, shielded: false, placedSeq: cell.placedSeq }
      : c,
  );
}

export const marksOf = (board: CellState[], mark: Mark): number =>
  board.filter((c) => c.kind === 'mark' && c.mark === mark).length;
