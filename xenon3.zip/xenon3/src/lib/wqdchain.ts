// ─────────────────────────────────────────────────────────────────────────────
// wqdchain — WebQuid mainnet ("webquid-mainnet-1") wire formats, reimplemented
// from the terminal's public client so Xenon3 can verify deposits trustlessly.
//
// Every primitive here was cross-checked against the live chain: recomputing
// the genesis block with these exact functions yields the network's pinned
// genesis hash 207d9fa1…530ef7.
//
// Address:   wqd1 + RIPEMD160(SHA256(compressed pubkey)) + checksum8
//            checksum = D("wqd1" + payload).slice(0,8)
// Transfer:  sign ECDSA (64-byte compact r‖s, low-S) over
//            D("WQDTX2|webquid-mainnet-1|from|to|amount|fee|nonce")
//            (terminal's noble default prehash makes every signed digest D)
//            txid  = D(preimage + "|" + pubkey + "|" + signature)
// Block:     hash = D("WQD1|height|prevHash|merkleRoot|timestamp|nonce")
//            PoW  = hash < target (lexicographic hex)
// Merkle:    pairwise D(a+b), odd leaf duplicated; leaves =
//            [coinbaseTxid, …popTxids, …transferTxids]
// Coinbase:  D("WQDCB1|height|to|amount")   PoP: D("WQDPOP1|height|index|to|amount")
// D(t) = hex(SHA256(SHA256(utf8(t))))
// ─────────────────────────────────────────────────────────────────────────────

import { sha256 } from '@noble/hashes/sha2';
import { ripemd160 } from '@noble/hashes/ripemd160';
import { keccak_256 } from '@noble/hashes/sha3';
import { bytesToHex, hexToBytes, utf8ToBytes } from '@noble/hashes/utils';
import { secp256k1 } from '@noble/curves/secp256k1';

/** Double-SHA256 hex — the chain's universal hash `D`. */
export const hashD = (text: string): string => bytesToHex(sha256(sha256(utf8ToBytes(text))));

/**
 * Signature digest — the chain signs/verifies ECDSA over the DOUBLE-SHA256
 * of the ASCII preimage. The terminal's helper looks like a single SHA-256,
 * but its noble `sign`/`verify` calls run with the library's default
 * `prehash: true`, so the single-hashed preimage is hashed a second time.
 * Verified against live mainnet block #1's PoP attestation: only the
 * double-SHA256 digest verifies. `{ prehash: false }` is pinned explicitly
 * so the behavior cannot drift with noble defaults.
 */
export const sigDigest = (preimage: string): Uint8Array => sha256(sha256(utf8ToBytes(preimage)));
const NO_PREHASH = { prehash: false } as const;

export const WQD_CHAIN_ID = 'webquid-mainnet-1';
export const WQD_P2P_VERSION = 2;
export const WQD_AGENT = 'webquid-web-mainnet/2.0';
export const WQD_PEER_NAMESPACE = 'wqd-mainnet1';
export const WQD_CHALLENGE_PREFIX = '0000';
/** 1 WQD = 10^8 base units on-chain. */
export const WQD_BASE = 1e8;

// ── Consensus constants (lifted byte-exact from the terminal client) ─────────
/** Retarget every Z blocks. */
export const WQD_RETARGET_INTERVAL = 8;
/** Target block time (seconds). */
export const WQD_BLOCK_TIME = 60;
/** Retarget clamp: window elapsed confined to [n/4, n*4]. */
export const WQD_RETARGET_CLAMP = 4;
/** Median-time-past window. */
export const WQD_MTP_WINDOW = 11;
/** Genesis (and maximum) target: 000003ff…ff. */
export const WQD_GENESIS_TARGET = `000003${'f'.repeat(58)}`;
/** Bootstrap: blocks 1..999 pay 500 WQD (50 × 10), then floor(50e8·e^(-5e-6·(h-1000))). */
export const WQD_BOOTSTRAP_UNTIL = 1000;
/** Max PoP recipients per block. */
export const WQD_MAX_POP = 32;
/** Consensus constants aligned with the terminal's contracts/protocol.ts. */
export const WQD_MIN_TX_FEE = 1_000; // base units (0.00001 WQD)
export const WQD_MAX_MONEY = 42_000_000 * WQD_BASE; // soft cap (sanity bound)
export const WQD_MAX_TXS_PER_BLOCK = 64; // transfers per block (coinbase extra)
export const WQD_MAX_FUTURE_DRIFT_S = 900; // seconds a block may be ahead
export const WQD_MINER_COOLDOWN_HEIGHT = 2_000; // from here, prev miner sits out
export const WQD_POP_ATTEST_MAX_AGE_S = 300; // attestation freshness vs block ts

const targetToBig = (t: string): bigint => BigInt(`0x${t}`);
const bigToTarget = (b: bigint): string => b.toString(16).padStart(64, '0');

/** Block reward in whole-WQD base units (integer base units, 1 WQD = 1e8).
 *  Consensus-exact with the terminal: the exponential is floored in BASE
 *  UNITS (Math.floor(5e9 · e^-…)), not in whole WQD — flooring in WQD first
 *  diverges from the live chain from block #1001 onward and stalls sync. */
export const blockReward = (height: number): number => {
  if (height <= 0) return 0;
  if (height < WQD_BOOTSTRAP_UNTIL) return 500 * WQD_BASE;
  return Math.floor(50 * WQD_BASE * Math.exp(-5e-6 * (height - WQD_BOOTSTRAP_UNTIL)));
};

/** Consensus split of the block reward: 70% miner, 20% PoP pool, rest burned. */
export function rewardSplit(height: number, popCount: number): { miner: number; perPop: number } {
  const total = blockReward(height);
  const miner = Math.floor(total * 0.7);
  const popTotal = Math.floor(total * 0.2);
  const online = Math.max(0, Math.min(popCount, WQD_MAX_POP));
  const perPop = online > 0 ? Math.floor(popTotal / online) : 0;
  return { miner, perPop };
}

/** The exact retarget rule: height % 8 === 0 adjusts by clamped window time. */
export function expectedTarget(height: number, prev: { target: string; timestamp: number }, windowStartTimestamp?: number): string {
  if (height === 0) return WQD_GENESIS_TARGET;
  if (height % WQD_RETARGET_INTERVAL !== 0) return prev.target;
  if (windowStartTimestamp === undefined) return prev.target; // caller must supply
  const n = WQD_RETARGET_INTERVAL * WQD_BLOCK_TIME; // 480s expected
  const elapsed = prev.timestamp - windowStartTimestamp;
  const s = Math.min(Math.max(Math.floor(elapsed), Math.floor(n / WQD_RETARGET_CLAMP)), n * WQD_RETARGET_CLAMP);
  let next = (targetToBig(prev.target) * BigInt(s)) / BigInt(n);
  if (next > targetToBig(WQD_GENESIS_TARGET)) next = targetToBig(WQD_GENESIS_TARGET);
  if (next < 1n) next = 1n;
  return bigToTarget(next);
}

/** Median time past of the given (chronological) block timestamps. */
export function medianTimePast(timestamps: number[]): number {
  if (timestamps.length === 0) return 0;
  const sorted = [...timestamps].sort((a, b) => a - b);
  return sorted[Math.floor((sorted.length - 1) / 2)];
}

export function wqd1FromPayload(payload40: string): string {
  return `wqd1${payload40}${hashD(`wqd1${payload40}`).slice(0, 8)}`;
}

/** Terminal-format address for a compressed secp256k1 pubkey (hex). */
export function wqd1FromPubkey(pubkeyHex: string): string {
  return wqd1FromPayload(bytesToHex(ripemd160(sha256(hexToBytes(pubkeyHex)))));
}

/** Terminal-format address for a raw private key (0x-hex). */
export function wqd1FromPrivkey(privHex: string): string {
  const pub = secp256k1.getPublicKey(hexToBytes(privHex.replace(/^0x/, '')), true);
  return wqd1FromPubkey(bytesToHex(pub));
}

/**
 * The Ethereum-style address of the SAME key that owns a compressed pubkey —
 * binds a wqd1 deposit sender to the Xenon3 wallet identity (0x…) it maps to.
 */
export function ethAddressFromPubkey(compressedPubHex: string): string {
  const point = secp256k1.ProjectivePoint.fromHex(hexToBytes(compressedPubHex));
  const uncompressed = point.toRawBytes(false); // 65 bytes, leading 0x04
  return `0x${bytesToHex(keccak_256(uncompressed.slice(1))).slice(-40)}`;
}

const WQD1_PATTERN = /^wqd1[0-9a-f]{48}$/;

export function isValidWqd1Address(address: string): boolean {
  if (!WQD1_PATTERN.test(address)) return false;
  const payload = address.slice(4, 44);
  return address.slice(44) === hashD(`wqd1${payload}`).slice(0, 8);
}

// ── Transfers ────────────────────────────────────────────────────────────────

export interface WqdTransfer {
  fromAddress: string;
  toAddress: string;
  /** integer base units (1 WQD = 1e8) */
  amount: number;
  fee: number;
  nonce: number;
  pubkey: string;
  signature: string;
  timestamp: number;
}

export const transferPreimage = (tx: Pick<WqdTransfer, 'fromAddress' | 'toAddress' | 'amount' | 'fee' | 'nonce'>): string =>
  `WQDTX2|${WQD_CHAIN_ID}|${tx.fromAddress}|${tx.toAddress}|${tx.amount}|${tx.fee}|${tx.nonce}`;

/** Legacy pre-chainId preimage — the network accepted these before v2. */
const transferPreimageV1 = (tx: Pick<WqdTransfer, 'fromAddress' | 'toAddress' | 'amount' | 'fee' | 'nonce'>): string =>
  `WQDTX1|${tx.fromAddress}|${tx.toAddress}|${tx.amount}|${tx.fee}|${tx.nonce}`;

export const transferTxid = (tx: WqdTransfer): string =>
  hashD(`${transferPreimage(tx)}|${tx.pubkey}|${tx.signature}`);

/**
 * Classify a transfer exactly like the terminal: v2 (chainId-bound) or legacy
 * v1 signature. Returns the version and the matching txid, or 0 when neither
 * signature verifies. Blocks may carry either; deposits are strict v2.
 */
export function classifyTransfer(tx: WqdTransfer): { version: 1 | 2; txid: string } | null {
  try {
    if (!/^[0-9a-f]{128}$/.test(tx.signature)) return null;
    if (!/^(02|03)[0-9a-f]{64}$/.test(tx.pubkey)) return null;
    if (wqd1FromPubkey(tx.pubkey) !== tx.fromAddress) return null;
    const sig = hexToBytes(tx.signature);
    const pub = hexToBytes(tx.pubkey);
    if (secp256k1.verify(sig, sigDigest(transferPreimage(tx)), pub, NO_PREHASH)) {
      return { version: 2, txid: hashD(`${transferPreimage(tx)}|${tx.pubkey}|${tx.signature}`) };
    }
    if (secp256k1.verify(sig, sigDigest(transferPreimageV1(tx)), pub, NO_PREHASH)) {
      return { version: 1, txid: hashD(`${transferPreimageV1(tx)}|${tx.pubkey}|${tx.signature}`) };
    }
    return null;
  } catch {
    return null;
  }
}

/** ECDSA compact (r‖s, low-S) over the double-SHA256 of the preimage. */
export function verifyTransferSignature(tx: WqdTransfer): boolean {
  try {
    if (!/^[0-9a-f]{128}$/.test(tx.signature)) return false;
    if (!/^(02|03)[0-9a-f]{64}$/.test(tx.pubkey)) return false;
    if (wqd1FromPubkey(tx.pubkey) !== tx.fromAddress) return false;
    return secp256k1.verify(
      hexToBytes(tx.signature),
      sigDigest(transferPreimage(tx)),
      hexToBytes(tx.pubkey),
      NO_PREHASH,
    );
  } catch {
    return false;
  }
}

// ── Blocks ───────────────────────────────────────────────────────────────────

export interface WqdPopTransfer {
  address: string;
  amount: number;
  index: number;
}

export interface WqdPopAttestation {
  address: string;
  pubkey: string;
  signature: string;
  timestamp: number;
}

/** A transaction row as gossiped inside a block's `txs` array. */
export interface WqdWireTx {
  txid: string;
  type: 'coinbase' | 'transfer';
  fromAddress: string | null;
  toAddress: string;
  amount: number;
  fee: number;
  nonce: number | null;
  pubkey: string | null;
  signature: string | null;
  timestamp: number;
}

/** The WebQuid wire block, exactly as gossiped in `block`/`blocks` messages. */
export interface WqdBlock {
  height: number;
  hash: string;
  prevHash: string;
  merkleRoot: string;
  timestamp: number;
  nonce: number;
  target: string;
  miner: string;
  message?: string | null;
  txs: WqdWireTx[];
  popTransfers: WqdPopTransfer[];
  minerPeerId?: string | null;
  popAttestations?: WqdPopAttestation[];
  feesBurned?: number | string;
}

/** Spendable transfers inside a wire block (coinbase row excluded). */
export const blockTransfers = (block: WqdBlock): WqdTransfer[] =>
  block.txs
    .filter((t) => t.type === 'transfer')
    .map((t) => ({
      fromAddress: t.fromAddress ?? '',
      toAddress: t.toAddress,
      amount: Number(t.amount),
      fee: Number(t.fee),
      nonce: t.nonce ?? 0,
      pubkey: t.pubkey ?? '',
      signature: t.signature ?? '',
      timestamp: t.timestamp,
    }));

/** The coinbase row of a wire block (txs[0] by consensus). */
export const blockCoinbase = (block: WqdBlock): WqdWireTx | null =>
  block.txs.find((t) => t.type === 'coinbase') ?? null;

export const blockHashPreimage = (b: Pick<WqdBlock, 'height' | 'prevHash' | 'merkleRoot' | 'timestamp' | 'nonce'>): string =>
  `WQD1|${b.height}|${b.prevHash}|${b.merkleRoot}|${b.timestamp}|${b.nonce}`;

export const computeBlockHash = (b: Pick<WqdBlock, 'height' | 'prevHash' | 'merkleRoot' | 'timestamp' | 'nonce'>): string =>
  hashD(blockHashPreimage(b));

export const coinbaseTxid = (height: number, to: string, amount: number): string =>
  hashD(`WQDCB1|${height}|${to}|${amount}`);

export const popTxid = (height: number, index: number, to: string, amount: number): string =>
  hashD(`WQDPOP1|${height}|${index}|${to}|${amount}`);

/** Pairwise double-SHA256 merkle over hex leaves; odd leaf duplicated. */
export function merkleRoot(leaves: string[]): string {
  if (leaves.length === 0) return '0'.repeat(64);
  let level = leaves.slice();
  while (level.length > 1) {
    const next: string[] = [];
    for (let i = 0; i < level.length; i += 2) {
      const right = i + 1 < level.length ? level[i + 1] : level[i];
      next.push(hashD(level[i] + right));
    }
    level = next;
  }
  return level[0];
}

/** Recompute the merkle root from a wire block's declared contents.
 *  Uses the declared (already signature-verified) txids as transfer leaves. */
export function blockMerkleRoot(block: WqdBlock): string {
  const cb = blockCoinbase(block);
  if (!cb) return '';
  const leaves = [
    cb.txid,
    ...block.popTransfers.map((p) => popTxid(block.height, p.index, p.address, Number(p.amount))),
    ...block.txs.filter((t) => t.type === 'transfer').map((t) => t.txid),
  ];
  return merkleRoot(leaves);
}

/** Full local validation: hash, PoW, coinbase, merkle, and every signature. */
export function verifyBlock(block: WqdBlock): { ok: boolean; error: string | null } {
  if (!/^[0-9a-f]{64}$/.test(block.hash)) return { ok: false, error: 'bad hash shape' };
  if (computeBlockHash(block) !== block.hash) return { ok: false, error: 'block hash mismatch' };
  if (!(block.hash < block.target)) return { ok: false, error: 'insufficient proof-of-work' };
  const cb = blockCoinbase(block);
  if (!cb) return { ok: false, error: 'no coinbase row' };
  if (coinbaseTxid(block.height, cb.toAddress, Number(cb.amount)) !== cb.txid) {
    return { ok: false, error: 'coinbase txid mismatch' };
  }
  for (const t of block.txs) {
    if (t.type === 'coinbase') continue;
    const wire: WqdTransfer = {
      fromAddress: t.fromAddress ?? '', toAddress: t.toAddress, amount: Number(t.amount),
      fee: Number(t.fee), nonce: t.nonce ?? 0, pubkey: t.pubkey ?? '',
      signature: t.signature ?? '', timestamp: t.timestamp,
    };
    const cls = classifyTransfer(wire); // v2 or legacy v1 — both valid on-chain
    if (!cls) return { ok: false, error: `bad tx signature ${(t.txid ?? '').slice(0, 12)}` };
    if (cls.txid !== t.txid) return { ok: false, error: 'txid mismatch in block' };
  }
  if (blockMerkleRoot(block) !== block.merkleRoot) return { ok: false, error: 'merkle root mismatch' };
  return { ok: true, error: null };
}

function computeGenesisHash(): string {
  const cb = coinbaseTxid(0, wqd1FromPayload('0'.repeat(40)), 0);
  const root = merkleRoot([cb]);
  return computeBlockHash({
    height: 0,
    prevHash: '0'.repeat(64),
    merkleRoot: root,
    timestamp: 1_790_726_400,
    nonce: 0,
  });
}

/** Synthesize the genesis block locally — its hash is pinned (Pr[0]), so no
 *  peer input is involved. */
export function synthGenesis(): WqdBlock {
  const cbTxid = coinbaseTxid(0, WQD_ZERO_ADDRESS, 0);
  return {
    height: 0,
    hash: WQD_GENESIS_HASH,
    prevHash: '0'.repeat(64),
    merkleRoot: merkleRoot([cbTxid]),
    timestamp: 1_790_726_400,
    nonce: 0,
    target: WQD_GENESIS_TARGET,
    miner: WQD_ZERO_ADDRESS,
    message: null,
    txs: [{
      txid: cbTxid, type: 'coinbase', fromAddress: null, toAddress: WQD_ZERO_ADDRESS,
      amount: 0, fee: 0, nonce: null, pubkey: null, signature: null, timestamp: 1_790_726_400,
    }],
    popTransfers: [],
    minerPeerId: null,
    popAttestations: [],
  };
}

/** Context a full node has about the chain before `block`. */
export interface ChainContext {
  prev: WqdBlock;
  windowStart: WqdBlock | null; // block at height-8 (required when height%8===0)
  recentTimestamps: number[];   // up to 11 timestamps of blocks before this one
  /**
   * Check one transfer against pending account state and apply it (nonce
   * sequence + funds) — intra-block effects must be visible to later txs.
   * Return null on success, an error string on violation.
   */
  applyTransfer: (tx: WqdTransfer) => string | null;
}

/** Full consensus check of one block extending the known chain. */
/**
 * PoP attestation signature check — consensus-exact with the terminal:
 * compressed pubkey derives the payout address, ECDSA (single SHA-256)
 * verifies over the canonical preimage binding miner peer id + address +
 * timestamp, so an attestation cannot be replayed for another miner.
 */
export function verifyPopAttestationSignature(a: {
  minerPeerId: string;
  address: string;
  timestamp: number;
  pubkey: string;
  signature: string;
}): boolean {
  try {
    if (!/^[0-9a-f]{128}$/.test(a.signature)) return false;
    if (!/^(02|03)[0-9a-f]{64}$/.test(a.pubkey)) return false;
    if (wqd1FromPubkey(a.pubkey) !== a.address) return false;
    return secp256k1.verify(
      hexToBytes(a.signature),
      sigDigest(`WQDPOP_ATTEST|${a.minerPeerId}|${a.address}|${a.timestamp}`),
      hexToBytes(a.pubkey),
      NO_PREHASH,
    );
  } catch {
    return false;
  }
}

/**
 * Block-level PoP attestation gate (consensus, from applyBlockInTx):
 * no attestations ⇒ no PoP transfers (pool burns); otherwise the miner must
 * publish its peer id, every attestation must be fresh (±300s of the block
 * timestamp), correctly signed, distinct per address, never self-attesting —
 * and the attested address set must match the popTransfer set EXACTLY.
 */
export function validatePopAttestations(block: {
  minerPeerId: string | null;
  miner: string;
  timestamp: number;
  popTransfers: WqdPopTransfer[];
  popAttestations: WqdPopAttestation[];
}): boolean {
  const atts = block.popAttestations;
  if (atts.length === 0) return block.popTransfers.length === 0;
  if (block.minerPeerId === null || block.minerPeerId.length === 0) return false;
  if (atts.length > WQD_MAX_POP) return false;
  const attested: string[] = [];
  for (const a of atts) {
    if (!Number.isInteger(a.timestamp)) return false;
    if (Math.abs(block.timestamp - a.timestamp) > WQD_POP_ATTEST_MAX_AGE_S) return false;
    if (!isValidWqd1Address(a.address)) return false;
    if (a.address === block.miner) return false; // miner cannot attest itself
    if (!verifyPopAttestationSignature({ minerPeerId: block.minerPeerId, ...a })) return false;
    attested.push(a.address);
  }
  if (new Set(attested).size !== attested.length) return false; // one address, one share
  if (attested.length !== block.popTransfers.length) return false;
  const lhs = attested.slice().sort();
  const rhs = block.popTransfers.map((pt) => pt.address).sort();
  return lhs.every((addr, i) => addr === rhs[i]);
}

/** Consensus: from height 2000 the previous block's miner must sit one out. */
export const violatesMinerCooldown = (height: number, miner: string, prevMiner: string | null): boolean =>
  height >= WQD_MINER_COOLDOWN_HEIGHT && prevMiner !== null && miner === prevMiner;

export function verifyChainBlock(block: WqdBlock, ctx: ChainContext): { ok: boolean; error: string | null } {
  if (block.height !== ctx.prev.height + 1) return { ok: false, error: 'height not sequential' };
  if (block.prevHash !== ctx.prev.hash) return { ok: false, error: 'broken chain link' };
  if (block.height % WQD_RETARGET_INTERVAL === 0 && !ctx.windowStart) {
    return { ok: false, error: 'retarget window missing' };
  }
  const wantTarget = expectedTarget(block.height, ctx.prev, ctx.windowStart?.timestamp);
  if (block.target !== wantTarget) return { ok: false, error: 'wrong difficulty target' };
  const mtp = medianTimePast(ctx.recentTimestamps.slice(-WQD_MTP_WINDOW));
  if (!Number.isInteger(block.timestamp) || block.timestamp < Math.max(mtp + 1, ctx.prev.timestamp + 1)) {
    return { ok: false, error: 'timestamp too old' };
  }
  if (block.timestamp > Math.floor(Date.now() / 1000) + WQD_MAX_FUTURE_DRIFT_S) {
    return { ok: false, error: 'timestamp too far in the future' };
  }
  // Miner cooldown (consensus from #2000): same miner twice in a row is invalid.
  if (violatesMinerCooldown(block.height, block.miner, ctx.prev.miner ?? null)) {
    return { ok: false, error: 'miner cooldown: same miner as the previous block' };
  }
  // ── shape gates (terminal: applyWireBlockLocked) ─────────────────────────
  if (!isValidWqd1Address(block.miner)) return { ok: false, error: 'invalid miner address' };
  if (!Number.isInteger(block.nonce) || block.nonce < 0 || block.nonce > Number.MAX_SAFE_INTEGER) {
    return { ok: false, error: 'bad nonce' };
  }
  if (!Array.isArray(block.txs) || block.txs.length < 1 || block.txs.length > WQD_MAX_TXS_PER_BLOCK + 1) {
    return { ok: false, error: 'bad tx count' };
  }
  // The coinbase is txs[0], exactly, with every non-payment field nulled and
  // the block's own timestamp — no second coinbase row may appear later.
  const cbRow = block.txs[0];
  if (
    cbRow.type !== 'coinbase' ||
    cbRow.fromAddress !== null ||
    cbRow.fee !== 0 ||
    cbRow.nonce !== null ||
    cbRow.pubkey !== null ||
    cbRow.signature !== null ||
    cbRow.timestamp !== block.timestamp
  ) {
    return { ok: false, error: 'malformed coinbase' };
  }
  if (block.txs.slice(1).some((t) => t.type !== 'transfer')) {
    return { ok: false, error: 'coinbase must come first' };
  }
  // hash + PoW + coinbase txid + transfer signatures + merkle
  const base = verifyBlock(block);
  if (!base.ok) return base;
  const cb = blockCoinbase(block);
  if (!cb) return { ok: false, error: 'no coinbase row' };
  const split = rewardSplit(block.height, block.popTransfers.length);
  if (cb.toAddress !== block.miner) return { ok: false, error: 'coinbase payee is not the miner' };
  if (Number(cb.amount) !== split.miner) return { ok: false, error: 'coinbase overpays the schedule' };
  // ── PoP split shape + cryptographic attestation gate ─────────────────────
  if (block.popTransfers.length > WQD_MAX_POP) return { ok: false, error: 'too many PoP transfers' };
  const seenPopIdx = new Set<number>();
  for (const p of block.popTransfers) {
    if (!isValidWqd1Address(p.address)) return { ok: false, error: 'bad PoP address' };
    if (p.address === block.miner) return { ok: false, error: 'miner cannot be a PoP recipient' };
    if (!Number.isInteger(Number(p.amount)) || Number(p.amount) < 0) return { ok: false, error: 'bad PoP amount' };
    if (Number(p.amount) !== split.perPop) return { ok: false, error: 'PoP amount off schedule' };
    if (!Number.isInteger(p.index) || p.index < 0 || p.index >= block.popTransfers.length || seenPopIdx.has(p.index)) {
      return { ok: false, error: 'bad PoP index' };
    }
    seenPopIdx.add(p.index);
  }
  if (seenPopIdx.size !== block.popTransfers.length) return { ok: false, error: 'PoP indexes not dense' };
  if (
    !validatePopAttestations({
      minerPeerId: block.minerPeerId ?? null,
      miner: block.miner,
      timestamp: block.timestamp,
      popTransfers: block.popTransfers,
      popAttestations: block.popAttestations ?? [],
    })
  ) {
    return { ok: false, error: 'invalid PoP attestations' };
  }
  // ── transfer shape gates (stateless; signatures already checked above) ───
  const seenTx = new Set<string>([cb.txid]);
  for (const tx of blockTransfers(block)) {
    if (!isValidWqd1Address(tx.fromAddress) || !isValidWqd1Address(tx.toAddress)) {
      return { ok: false, error: 'invalid address in transfer' };
    }
    if (!Number.isInteger(tx.amount) || tx.amount < 1) return { ok: false, error: 'bad transfer amount' };
    if (!Number.isInteger(tx.fee) || tx.fee < WQD_MIN_TX_FEE) return { ok: false, error: 'fee below minimum' };
    if (tx.amount + tx.fee > WQD_MAX_MONEY) return { ok: false, error: 'amount too large' };
    if (!Number.isInteger(tx.nonce) || tx.nonce < 0 || tx.nonce > 2 ** 31 - 1) {
      return { ok: false, error: 'bad tx nonce' };
    }
    if (!Number.isInteger(tx.timestamp) || tx.timestamp < 1_500_000_000) {
      return { ok: false, error: 'bad tx timestamp' };
    }
    const cls = classifyTransfer(tx);
    if (!cls || seenTx.has(cls.txid)) return { ok: false, error: 'duplicate tx in block' };
    seenTx.add(cls.txid);
  }
  // account rules: nonce sequence + sufficient funds (sender pays amount + fee)
  for (const tx of blockTransfers(block)) {
    const err = ctx.applyTransfer(tx);
    if (err) return { ok: false, error: err };
  }
  return { ok: true, error: null };
}

// ── Balance proofs (no-transfer mirror credits) ──────────────────────────────

/** A signed claim of an address's on-chain balance at a given height. */
export interface BalanceProof {
  wqdAddress: string;
  height: number;
  /** Full on-chain balance in integer base units (1 WQD = 1e8). */
  balance: number;
  pubkey: string;
  signature: string;
}

/** Preimage of a balance claim: binds wqd1 address, height and exact base units. */
export const balancePreimage = (wqdAddress: string, height: number, balance: number): string =>
  `WQDBAL1|${WQD_CHAIN_ID}|${wqdAddress}|${height}|${balance}`;

/** Sign a balance claim with the wallet's secp256k1 key (terminal-style ECDSA). */
export function signBalanceProof(privHex: string, wqdAddress: string, height: number, balance: number): { pubkey: string; signature: string } {
  const priv = hexToBytes(privHex.replace(/^0x/, ''));
  const pubkey = bytesToHex(secp256k1.getPublicKey(priv, true));
  const sig = secp256k1.sign(sigDigest(balancePreimage(wqdAddress, height, balance)), priv, NO_PREHASH);
  return { pubkey, signature: bytesToHex(sig.toCompactRawBytes()) };
}

/** Verify a balance claim's cryptography (chain-truth checked by the watcher). */
export function verifyBalanceProof(p: { wqdAddress: string; height: number; balance: number; pubkey: string; signature: string }): boolean {
  try {
    if (!isValidWqd1Address(p.wqdAddress)) return false;
    if (wqd1FromPubkey(p.pubkey) !== p.wqdAddress) return false;
    if (!Number.isInteger(p.height) || p.height < 0) return false;
    if (!Number.isInteger(p.balance) || p.balance < 0) return false;
    const sig = hexToBytes(p.signature);
    const pub = hexToBytes(p.pubkey);
    const preimage = balancePreimage(p.wqdAddress, p.height, p.balance);
    // Current convention: double-SHA256 (terminal-exact). Also accept the
    // single-SHA256 digest so balance proofs signed by pre-20261014e builds
    // stay valid — both digests are equally unforgeable without the key.
    return (
      secp256k1.verify(sig, sigDigest(preimage), pub, NO_PREHASH) ||
      secp256k1.verify(sig, sha256(utf8ToBytes(preimage)), pub, NO_PREHASH)
    );
  } catch {
    return false;
  }
}

// ── Deposit proofs (carried inside ledger CREDIT events) ─────────────────────

/** A compact, independently verifiable header for confirmation chaining. */
export interface WqdHeader {
  hash: string;
  prevHash: string;
  merkleRoot: string;
  timestamp: number;
  nonce: number;
  target: string;
}

export interface DepositProof {
  tx: WqdTransfer;
  txid: string;
  height: number;
  /** full inclusion context of the deposit block */
  block: WqdHeader & {
    coinbaseTxid: string;
    coinbaseAmount: number;
    miner: string;
    popTransfers: WqdPopTransfer[];
    txids: string[];
  };
  /** headers of the blocks buried on top (confirmation chain) */
  confirmations: WqdHeader[];
}

export const headerOf = (b: WqdBlock): WqdHeader => ({
  hash: b.hash,
  prevHash: b.prevHash,
  merkleRoot: b.merkleRoot,
  timestamp: b.timestamp,
  nonce: b.nonce,
  target: b.target,
});

/**
 * Verify a deposit claim end-to-end, deterministically:
 *  1. txid recomputes from the tx
 *  2. the tx is a sender-signed burn to the chain zero address
 *  3. the txid is inside the block's merkle root
 *  4. the block hash + PoW are valid
 *  5. the confirmation headers chain on top, each with valid PoW
 */
export function verifyDepositProof(proof: DepositProof): { ok: boolean; error: string | null } {
  const { tx } = proof;
  if (!isValidWqd1Address(tx.fromAddress) || !isValidWqd1Address(tx.toAddress)) {
    return { ok: false, error: 'malformed address in deposit tx' };
  }
  if (!Number.isInteger(tx.amount) || tx.amount < 1) return { ok: false, error: 'bad deposit amount' };
  if (tx.toAddress !== WQD_ZERO_ADDRESS) return { ok: false, error: 'deposit is not burned to the sink' };
  if (!verifyTransferSignature(tx)) return { ok: false, error: 'bad deposit signature' };
  const txid = transferTxid(tx);
  if (txid !== proof.txid) return { ok: false, error: 'txid mismatch' };

  const { block } = proof;
  const leaves = [
    block.coinbaseTxid,
    ...block.popTransfers.map((p) => popTxid(proof.height, p.index, p.address, p.amount)),
    ...block.txids,
  ];
  if (!block.txids.includes(txid)) return { ok: false, error: 'deposit not in block tx list' };
  if (merkleRoot(leaves) !== block.merkleRoot) return { ok: false, error: 'merkle mismatch' };
  if (computeBlockHash({ height: proof.height, ...block }) !== block.hash) {
    return { ok: false, error: 'block hash mismatch' };
  }
  if (!(block.hash < block.target)) return { ok: false, error: 'deposit block fails PoW' };

  let prev = block.hash;
  for (const [i, header] of proof.confirmations.entries()) {
    const height = proof.height + 1 + i;
    if (header.prevHash !== prev) return { ok: false, error: `confirmation ${i} broken link` };
    if (computeBlockHash({ height, ...header }) !== header.hash) {
      return { ok: false, error: `confirmation ${i} hash mismatch` };
    }
    if (!(header.hash < header.target)) return { ok: false, error: `confirmation ${i} fails PoW` };
    prev = header.hash;
  }
  return { ok: true, error: null };
}

// ── Eager constants (declared last: they call the functions above) ───────────

/** Deposits are burned to the chain's own zero address (the genesis miner). */
export const WQD_ZERO_ADDRESS = wqd1FromPayload('0'.repeat(40));
export const WQD_GENESIS_HASH = computeGenesisHash();
