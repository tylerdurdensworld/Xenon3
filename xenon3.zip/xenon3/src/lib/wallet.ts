// ─────────────────────────────────────────────────────────────────────────────
// Xenon3 wallet layer (viem). Real ECDSA signers, one interface:
//   • WebQuid identity — the player's OWN wallet: an imported key, or a key
//     the WebQuid platform left on this origin. Xenon3 NEVER mints wallets.
//   • Injected browser wallet — any EIP-1193 provider (personal_sign capable).
// Both produce signatures the peer can recover and verify. No custodial keys,
// no funds at risk: signatures only authenticate in-game actions and WQD burns.
// ─────────────────────────────────────────────────────────────────────────────

import { createWalletClient, custom, type Hex } from 'viem';
import { mainnet } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';
import {
  normalizePrivateKey,
  persistImportedKey,
  resolveWebquidIdentity,
  type WebquidIdentitySource,
} from './webquid';
import { wqd1FromPrivkey } from './wqdchain';

export interface GameSigner {
  address: string;
  mode: 'burner' | 'injected';
  /**
   * The key's address in WebQuid mainnet format (wqd1…) — only present for
   * key-based WebQuid identities. Drives the deposit bridge UI and watcher.
   */
  wqdAddress?: string;
  /**
   * The raw secp256k1 key — never leaves the device, never transmitted.
   * Used to sign local balance proofs for the chain mirror.
   */
  wqdKey?: Hex;
  signMessage: (args: { message: string }) => Promise<Hex>;
}

export type { WebquidIdentitySource };

export interface WebquidConnection {
  signer: GameSigner;
  /** Where the identity came from — drives the UI's "found your wallet" hints. */
  source: WebquidIdentitySource;
}

const signerFromKey = (key: Hex): GameSigner => {
  const account = privateKeyToAccount(key);
  return {
    address: account.address.toLowerCase(),
    mode: 'burner',
    wqdAddress: wqd1FromPrivkey(key),
    wqdKey: key,
    signMessage: (args) => account.signMessage(args),
  };
};

/**
 * Connect with the player's real WebQuid wallet (imported key, then platform
 * key on this origin). Returns null when no genuine wallet exists — Xenon3
 * refuses to fabricate one.
 */
export async function connectWebquid(): Promise<WebquidConnection | null> {
  const identity = resolveWebquidIdentity();
  if (!identity) return null;
  return { signer: signerFromKey(identity.key), source: identity.source };
}

/** Import the wallet key exported from the player's WebQuid account. */
export async function importWebquidWallet(rawKey: string): Promise<WebquidConnection> {
  const key = normalizePrivateKey(rawKey); // throws a friendly error on bad input
  persistImportedKey(key);
  return { signer: signerFromKey(key), source: 'imported' };
}

interface Eip1193Provider {
  request: (args: { method: string; params?: unknown[] | Record<string, unknown> }) => Promise<unknown>;
}

export function injectedProvider(): Eip1193Provider | null {
  if (typeof window === 'undefined') return null;
  const candidate = (window as unknown as { ethereum?: Eip1193Provider }).ethereum;
  return candidate ?? null;
}

export async function connectInjected(): Promise<GameSigner> {
  const provider = injectedProvider();
  if (!provider) throw new Error('no injected EIP-1193 wallet found');
  const client = createWalletClient({ chain: mainnet, transport: custom(provider) });
  const [address] = await client.requestAddresses();
  if (!address) throw new Error('wallet rejected the connection request');
  return {
    address: address.toLowerCase(),
    mode: 'injected',
    signMessage: async ({ message }) => client.signMessage({ account: address, message }),
  };
}
