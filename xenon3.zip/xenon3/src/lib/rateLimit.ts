// ─────────────────────────────────────────────────────────────────────────────
// Token-bucket rate limiter — used for outbound chat etiquette and for inbound
// flood defense on the DataChannel.
// ─────────────────────────────────────────────────────────────────────────────

export class TokenBucket {
  private tokens: number;
  private lastRefill: number;

  constructor(
    private readonly capacity: number,
    private readonly refillPerSecond: number,
  ) {
    this.tokens = capacity;
    this.lastRefill = Date.now();
  }

  /** Consume `count` tokens if available; refills lazily by wall-clock delta. */
  tryConsume(count = 1): boolean {
    const now = Date.now();
    const elapsedSeconds = (now - this.lastRefill) / 1000;
    this.tokens = Math.min(this.capacity, this.tokens + elapsedSeconds * this.refillPerSecond);
    this.lastRefill = now;
    if (this.tokens < count) return false;
    this.tokens -= count;
    return true;
  }

  get available(): number {
    this.tryConsume(0);
    return this.tokens;
  }
}
