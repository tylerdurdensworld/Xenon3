// ─────────────────────────────────────────────────────────────────────────────
// useWebRTC — serverless P2P transport over PeerJS (WebRTC DataChannel).
//
// PRIVATE MATCH:
//   • HOST registers a deterministic peer id  xenon3-<ROOMCODE>  — that IS the
//     room. Guests dial it directly. The public PeerJS cloud brokers signaling;
//     set NEXT_PUBLIC_PEER_* env vars to point at your own PeerServer/relay.
//
// QUICK MATCH (serverless global queue, no backend):
//   • One well-known rendezvous id  xenon3-quickmatch-v1  acts as the queue
//     node. Whoever registers it first HOLDS the queue; later arrivals dial it.
//   • Holder accepts the first challenger (store phase is IDLE) and the pair
//     runs the standard signed HELLO handshake against the synthetic
//     QUICKMATCH_CODE room. While busy, the holder answers {queueBusy:true}
//     control frames so seekers back off and retry with jitter.
//   • If the node vanishes mid-dial (holder closed the tab), the seeker flips
//     and claims the node itself — the queue self-heals without any server.
//
// COMMON:
//   • After the channel opens, a signed HELLO/HELLO_ACK handshake exchanges
//     WQD ledger snapshots and derives the matchId from both nonces.
//   • Every envelope is validated by the store (seq, hash chain, signature,
//     game rules). The channel is reliable+ordered; the store still buffers
//     out-of-order frames defensively.
//   • A 10s PING carries a state hash; mismatches trigger host-authoritative
//     STATE_SYNC recovery. A 250ms local interval drives turn-clock timeouts.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import { useEffect, useRef } from 'react';
import Peer, { type DataConnection } from 'peerjs';
import { computeStateHash, useGameStore, type NetApi } from '../store/useGameStore';
import {
  QUICKMATCH_CODE,
  handshakeMatchId,
  type Envelope,
  type HelloPayload,
  type PingPayload,
} from '../lib/protocol';

const roomPeerId = (code: string): string => `xenon3-${code}`;

/** The one well-known rendezvous point for the global Quick Match queue. */
const QUEUE_PEER_ID = 'xenon3-quickmatch-v1';

/** Queue etiquette: how many times a seeker retries a busy node before giving up. */
const QUEUE_MAX_ATTEMPTS = 12;
const QUEUE_RETRY_MS = 2_500;
/** How often the guest retransmits its signed HELLO until the ACK lands. */
const HELLO_MAX_ATTEMPTS = 6;
const HELLO_RETRY_MS = 2_000;
/** A dialed channel that never opens (NAT/firewall) gives up after this. */
const DIAL_TIMEOUT_MS = 12_000;
/** Transient ICE blips heal themselves — sever only after this grace window. */
const ICE_GRACE_MS = 6_000;
/** Safety bound on holder→seeker→holder flips when the node keeps flapping. */
const MAX_NODE_CLAIMS = 3;

/** PeerJS broker config — public cloud by default, self-hostable via env. */
function peerOptions(): Record<string, unknown> {
  // ICE: explicit multi-STUN + the PeerJS public TURN pair. Passing our own
  // `config` REPLACES the library defaults, so the TURN relays are repeated
  // here verbatim — without them, two players behind symmetric NAT (home +
  // office, the classic duel setup) can signal but never open a channel.
  const config = {
    iceServers: [
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
      { urls: 'stun:stun.cloudflare.com:3478' },
      {
        urls: ['turn:us-0.turn.peerjs.com:3478', 'turn:eu-0.turn.peerjs.com:3478'],
        username: 'peerjs',
        credential: 'peerjsp',
      },
    ],
    iceCandidatePoolSize: 4,
  };
  const host = process.env.NEXT_PUBLIC_PEER_HOST;
  if (!host) return { debug: 0, config };
  return {
    host,
    port: Number(process.env.NEXT_PUBLIC_PEER_PORT ?? 443),
    path: process.env.NEXT_PUBLIC_PEER_PATH ?? '/',
    secure: (process.env.NEXT_PUBLIC_PEER_SECURE ?? 'true') === 'true',
    debug: 0,
    config,
  };
}

const isEnvelope = (value: unknown): value is Envelope => {
  if (typeof value !== 'object' || value === null) return false;
  const env = value as Record<string, unknown>;
  return (
    typeof env.v === 'number' &&
    typeof env.matchId === 'string' &&
    typeof env.seq === 'number' &&
    typeof env.prevHash === 'string' &&
    typeof env.type === 'string' &&
    typeof env.from === 'string' &&
    typeof env.sig === 'string'
  );
};

/** Control frames are unsigned JSON (never trusted for game state). */
interface QueueControlFrame {
  queueBusy?: boolean;
  /** Host saw our HELLO arrive from its OWN wallet address (two tabs, one key). */
  sameWallet?: boolean;
}

const isControlFrame = (value: unknown): value is QueueControlFrame => {
  if (typeof value !== 'object' || value === null) return false;
  return 'queueBusy' in value || 'sameWallet' in value;
};

export function useWebRTC(): void {
  const peerRef = useRef<Peer | null>(null);
  const connRef = useRef<DataConnection | null>(null);

  useEffect(() => {
    const store = useGameStore;

    // ── Queue bookkeeping. Effect-local mutable slots (NOT React refs: hooks
    // are illegal inside useEffect; these never need to trigger renders). ──
    const helloRetryRef = { current: null as number | null };
    const queueTimerRef = { current: null as number | null };
    const queueModeRef = { current: 'idle' as 'idle' | 'holder' | 'seeker' };
    const nodeClaimsRef = { current: 0 };

    const clearHelloRetry = (): void => {
      if (helloRetryRef.current !== null) {
        window.clearInterval(helloRetryRef.current);
        helloRetryRef.current = null;
      }
    };

    const clearQueueTimer = (): void => {
      if (queueTimerRef.current !== null) {
        window.clearTimeout(queueTimerRef.current);
        queueTimerRef.current = null;
      }
    };

    /** Channels WE closed on purpose (busy-backoff, teardown) must not trip
     *  the drop detector when their 'close' event lands later. */
    const intentionalClose = new WeakSet<DataConnection>();

    /** Abort a dialed channel that never opens instead of hanging forever. */
    const armDialTimeout = (conn: DataConnection, onTimeout: () => void): void => {
      const timer = window.setTimeout(() => {
        if (conn.open) return;
        intentionalClose.add(conn);
        try {
          conn.close();
        } catch {
          // already dead
        }
        onTimeout();
      }, DIAL_TIMEOUT_MS);
      conn.on('open', () => window.clearTimeout(timer));
    };

    const teardown = (): void => {
      clearHelloRetry();
      clearQueueTimer();
      queueModeRef.current = 'idle';
      try {
        if (connRef.current) intentionalClose.add(connRef.current);
        connRef.current?.close();
      } catch {
        // channel already dead
      }
      try {
        peerRef.current?.destroy();
      } catch {
        // peer already destroyed
      }
      connRef.current = null;
      peerRef.current = null;
    };

    /** Map PeerJS error types to player-readable, fail-safe UI states. */
    const reportPeerError = (context: 'host' | 'guest' | 'queue', error: unknown): void => {
      const type = (error as { type?: string }).type ?? '';
      if (type === 'unavailable-id' && context === 'host') {
        store.getState().setNetStatus('offline', 'room code already taken — roll a new one');
      } else if (type === 'peer-unavailable' && context === 'guest') {
        store.getState().setNetStatus('offline', 'room not found — check the code');
      } else if (type === 'network' || type === 'server-error') {
        store.getState().setNetStatus('offline', 'signaling relay unreachable');
      } else if (type === 'browser-incompatible') {
        store.getState().setNetStatus('offline', 'this browser lacks WebRTC support');
      }
      console.warn(`[xenon3] ${context} peer error:`, type, error);
    };

    /**
     * Attach the trust gate to a fresh DataConnection.
     * Non-envelope JSON control frames (queueBusy) are routed to `onControl`;
     * everything else must pass the store's signed-envelope gauntlet.
     */
    const wireConnection = (
      conn: DataConnection,
      onControl?: (frame: QueueControlFrame) => void,
    ): void => {
      connRef.current = conn;

      conn.on('data', (raw) => {
        let parsed: unknown = raw;
        if (typeof raw === 'string') {
          try {
            parsed = JSON.parse(raw);
          } catch {
            return; // non-JSON frame — not our protocol, ignore
          }
        }
        if (isControlFrame(parsed)) {
          onControl?.(parsed);
          return;
        }
        if (!isEnvelope(parsed)) return;
        void store.getState().applyRemote(parsed);
      });

      conn.on('close', () => {
        if (intentionalClose.has(conn)) return;
        const s = store.getState();
        if (s.phase === 'ACTIVE') {
          s.setNetStatus('offline', 'link lost');
          useGameStore.setState({ phase: 'ABORTED', netError: 'opponent disconnected' });
        } else if (s.phase === 'CONNECTING') {
          // The old guard only covered ACTIVE — a channel dying mid-handshake
          // left the lobby spinning "joining…" forever. Fail fast, reset clean.
          clearHelloRetry();
          s.setQueueStatus('idle');
          void s
            .leaveMatch()
            .then(() =>
              store
                .getState()
                .setNetStatus('offline', 'link dropped before the handshake — try again'),
            );
        }
      });

      // WiFi/NAT blips fire 'disconnected' and often heal within seconds — only
      // sever the match if the link is still dead after the grace window.
      let iceState = 'new';
      conn.on('iceStateChanged', (state) => {
        iceState = state;
        if (state !== 'disconnected' && state !== 'failed') return;
        window.setTimeout(() => {
          const s = store.getState();
          if (s.phase !== 'ACTIVE') return;
          if (iceState === 'connected' || iceState === 'completed') return; // healed
          if (intentionalClose.has(conn)) return;
          s.setNetStatus('offline', 'link lost');
          useGameStore.setState({ phase: 'ABORTED', netError: 'opponent disconnected' });
        }, ICE_GRACE_MS);
      });

      conn.on('error', (error) => {
        console.warn('[xenon3] data channel error:', error);
        store.getState().setNetStatus('offline', 'data channel fault');
      });
    };

    /** Politely refuse a second challenger while a match/handshake is live. */
    const rejectAsBusy = (conn: DataConnection): void => {
      conn.on('open', () => {
        try {
          conn.send(JSON.stringify({ queueBusy: true } satisfies QueueControlFrame));
        } catch {
          // channel died before we could answer — nothing more to do
        }
        // Give the frame a beat to flush before tearing down.
        window.setTimeout(() => {
          try {
            conn.close();
          } catch {
            // already closed
          }
        }, 500);
      });
    };

    /**
     * Guest-side HELLO loop. Retries retransmit the SAME signed envelope —
     * minting a fresh seq would open a gap in the host's inbound hash chain.
     */
    const startGuestHello = (): void => {
      clearHelloRetry();
      let attempts = 0;
      let helloEnv: Envelope | null = null;

      const sendHello = (): void => {
        const s = store.getState();
        if (s.phase !== 'CONNECTING' || s.peer) return; // handshake already done
        if (helloEnv) {
          api.sendRaw(helloEnv);
          return;
        }
        void s
          .dispatch('HELLO', {
            address: s.address ?? '',
            nonce: s.myNonce ?? ('0x' as never),
            ledger: s.ledger,
          } satisfies HelloPayload)
          .then((env) => {
            helloEnv = env;
          })
          .catch((error) => console.warn('[xenon3] failed to send HELLO:', error));
      };

      sendHello();
      helloRetryRef.current = window.setInterval(() => {
        attempts += 1;
        const s = store.getState();
        if (s.phase !== 'CONNECTING' || s.peer) {
          clearHelloRetry();
          return;
        }
        if (attempts > HELLO_MAX_ATTEMPTS) {
          clearHelloRetry();
          s.setQueueStatus('idle');
          s.setNetStatus('offline', 'host is not answering — try again');
          return;
        }
        sendHello();
      }, HELLO_RETRY_MS);
    };

    /** Guest-side handling for the host's same-wallet refusal. */
    const onSameWallet = (): void => {
      clearHelloRetry();
      store.getState().setQueueStatus('idle');
      store
        .getState()
        .setNetStatus('offline', 'same wallet on both sides — give one tab a sparring key');
    };

    /** Seeker side of Quick Match: dial the queue node, back off when busy. */
    const dialQueue = (attempt: number): void => {
      queueModeRef.current = 'seeker';
      store.getState().setQueueStatus(
        'dialing',
        attempt === 0
          ? 'QUEUE NODE FOUND — REQUESTING MATCH…'
          : `NODE BUSY — RETRY ${attempt}/${QUEUE_MAX_ATTEMPTS}`,
      );
      store.getState().setNetStatus('joining');

      const peer = new Peer(peerOptions());
      peerRef.current = peer;

      peer.on('open', () => {
        const conn = peer.connect(QUEUE_PEER_ID, { reliable: true });

        // Busy node or dead dial → unwind our half-started handshake and retry.
        const retryLater = (reason: 'busy' | 'timeout'): void => {
          clearHelloRetry();
          intentionalClose.add(conn);
          try {
            conn.close();
          } catch {
            // already closing
          }
          try {
            peer.destroy();
          } catch {
            // already destroyed
          }
          if (peerRef.current === peer) peerRef.current = null;
          if (connRef.current === conn) connRef.current = null;
          store.getState().resetQueueForRetry();
          if (attempt >= QUEUE_MAX_ATTEMPTS) {
            store.getState().setQueueStatus('idle');
            store
              .getState()
              .setNetStatus(
                'offline',
                reason === 'timeout'
                  ? 'queue node unreachable — host a private room instead'
                  : 'queue is full — host a private room instead',
              );
            return;
          }
          // Deterministic backoff + jitter so a crowd of seekers de-synchronizes.
          const jitter = Math.floor(Math.random() * 700);
          queueTimerRef.current = window.setTimeout(
            () => dialQueue(attempt + 1),
            QUEUE_RETRY_MS + jitter,
          );
        };

        wireConnection(conn, (frame) => {
          if (frame.sameWallet) {
            onSameWallet();
            return;
          }
          if (!frame.queueBusy) return;
          retryLater('busy');
        });
        armDialTimeout(conn, () => retryLater('timeout'));
        conn.on('open', () => {
          // Channel up → run the exact same signed handshake as a private guest.
          store.getState().beginHandshake(QUICKMATCH_CODE, 'guest');
          startGuestHello();
        });
      });

      peer.on('error', (error) => {
        const type = (error as { type?: string }).type ?? '';
        if (type === 'peer-unavailable') {
          // Queue node vanished between our lookup and our dial: the holder
          // left. Claim the node ourselves — the queue must self-heal.
          try {
            peer.destroy();
          } catch {
            // already destroyed
          }
          if (peerRef.current === peer) peerRef.current = null;
          if (nodeClaimsRef.current >= MAX_NODE_CLAIMS) {
            store.getState().setQueueStatus('idle');
            store.getState().setNetStatus('offline', 'queue unstable — try again in a moment');
            return;
          }
          nodeClaimsRef.current += 1;
          queueTimerRef.current = window.setTimeout(() => api.quickMatch(), 800);
          return;
        }
        store.getState().setQueueStatus('idle');
        reportPeerError('queue', error);
      });
    };

    const api: NetApi = {
      hostRoom: (code) => {
        teardown();
        store.getState().beginHandshake(code, 'host');
        store.getState().setNetStatus('hosting');
        const peer = new Peer(roomPeerId(code), peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          // Room registered — waiting for a challenger to dial in.
        });

        peer.on('connection', (conn) => {
          // Anti-hijack: once a handshake is in progress or a match is live,
          // any second dialer gets a polite busy refusal instead of the wire.
          if (store.getState().phase !== 'CONNECTING' || store.getState().peer) {
            rejectAsBusy(conn);
            return;
          }
          // Attach the data listener IMMEDIATELY — the guest's HELLO can arrive
          // in the same tick as 'open'; wiring inside 'open' risks losing it.
          wireConnection(conn, (frame) => {
            if (frame.queueBusy) return; // guests never send this; ignore
          });
        });

        peer.on('error', (error) => reportPeerError('host', error));
      },

      joinRoom: (code) => {
        teardown();
        store.getState().beginHandshake(code, 'guest');
        store.getState().setNetStatus('joining');
        const peer = new Peer(peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          const conn = peer.connect(roomPeerId(code), { reliable: true });
          wireConnection(conn, (frame) => {
            if (frame.sameWallet) {
              onSameWallet();
              return;
            }
            if (!frame.queueBusy) return;
            // Host refused us: the room is already playing someone else.
            clearHelloRetry();
            intentionalClose.add(conn);
            store.getState().setQueueStatus('idle');
            store.getState().setNetStatus('offline', 'room is already in a match');
          });
          // A dial that never opens (symmetric NAT, office firewall) used to
          // spin forever — fail with an actionable message instead.
          armDialTimeout(conn, () => {
            clearHelloRetry();
            store.getState().setQueueStatus('idle');
            void store
              .getState()
              .leaveMatch()
              .then(() =>
                store
                  .getState()
                  .setNetStatus(
                    'offline',
                    'host unreachable — the room is gone or a firewall blocked the P2P link',
                  ),
              );
          });
          conn.on('open', () => {
            startGuestHello();
          });
        });

        peer.on('error', (error) => reportPeerError('guest', error));
      },

      quickMatch: () => {
        teardown();
        nodeClaimsRef.current = 0;
        store.getState().setQueueStatus('holding', 'CLAIMING THE QUEUE NODE…');
        store.getState().setNetStatus('hosting');

        // Attempt to BECOME the queue node. If another player already holds
        // it, PeerJS fires 'unavailable-id' and we flip to seeker mode.
        const peer = new Peer(QUEUE_PEER_ID, peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          queueModeRef.current = 'holder';
          store
            .getState()
            .setQueueStatus('holding', 'HOLDING QUEUE NODE — first challenger gets the link');
        });

        peer.on('connection', (conn) => {
          // Accept only while we're idle in the lobby; mid-match challengers
          // get the busy frame so they keep hunting.
          if (store.getState().phase !== 'IDLE') {
            rejectAsBusy(conn);
            return;
          }
          store.getState().setQueueStatus('idle', null);
          store.getState().beginHandshake(QUICKMATCH_CODE, 'host');
          store.getState().setNetStatus('hosting');
          wireConnection(conn);
        });

        peer.on('error', (error) => {
          const type = (error as { type?: string }).type ?? '';
          if (type === 'unavailable-id' && queueModeRef.current === 'idle') {
            // Node is held by someone else → become a seeker and dial it.
            try {
              peer.destroy();
            } catch {
              // already destroyed
            }
            if (peerRef.current === peer) peerRef.current = null;
            dialQueue(0);
            return;
          }
          store.getState().setQueueStatus('idle');
          reportPeerError('queue', error);
        });
      },

      leave: () => {
        teardown();
        store.getState().setQueueStatus('idle');
        store.getState().setNetStatus('offline');
      },

      sendRaw: (env) => {
        const conn = connRef.current;
        if (conn && conn.open) {
          conn.send(JSON.stringify(env));
        }
      },

      sendControl: (frame) => {
        const conn = connRef.current;
        if (conn && conn.open) {
          try {
            conn.send(JSON.stringify(frame));
          } catch {
            // channel racing a close — advisory frame, safe to drop
          }
        }
      },
    };

    store.getState().setNetApi(api);

    // Turn-clock watchdog.
    const tickTimer = window.setInterval(() => store.getState().tick(), 250);

    // Desync detector: host-authoritative recovery via STATE_SYNC.
    const pingTimer = window.setInterval(() => {
      const s = store.getState();
      if (s.netStatus !== 'connected' || (s.phase !== 'ACTIVE' && s.phase !== 'FINISHED')) return;
      void s.dispatch('PING', {
        stateHash: computeStateHash(s.board, s.turn, s.winner),
      } satisfies PingPayload);
    }, 10_000);

    const onUnload = (): void => teardown();
    window.addEventListener('beforeunload', onUnload);

    return () => {
      window.clearInterval(tickTimer);
      window.clearInterval(pingTimer);
      window.removeEventListener('beforeunload', onUnload);
      teardown();
      store.getState().setNetApi(null);
    };
    // handshakeMatchId is referenced for protocol documentation; no reactive deps needed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  void handshakeMatchId;
}
