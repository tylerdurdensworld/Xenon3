// ParticleBurst — fragment stage: soft additive neon motes fading out with age.
uniform vec3 uColorA;
uniform vec3 uColorB;

varying float vLifeT;
varying float vSpeed;

void main() {
  // Radial soft-dot falloff inside the point sprite.
  vec2 centered = gl_PointCoord - 0.5;
  float dist = length(centered);
  float disc = smoothstep(0.5, 0.05, dist);

  float fade = pow(1.0 - vLifeT, 1.6);
  vec3 color = mix(uColorA, uColorB, vSpeed) * (1.4 + 2.2 * fade);
  float alpha = disc * fade;

  if (alpha < 0.01) discard;
  gl_FragColor = vec4(color, alpha);
}
