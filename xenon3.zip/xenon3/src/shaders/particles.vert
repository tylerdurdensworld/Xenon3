// ─────────────────────────────────────────────────────────────────────────────
// ParticleBurst — vertex stage: fully GPU-driven explosion. Each particle owns
// a random direction/speed seed; the CPU only uploads "when did we detonate".
// ─────────────────────────────────────────────────────────────────────────────

uniform float uAge;        // seconds since detonation
uniform float uLife;       // seconds until fully faded
uniform float uSpread;     // max travel distance
uniform float uPointScale; // pixel-size scaler (device pixel ratio aware)

attribute vec4 aSeed;      // xyz: normalized direction, w: speed 0..1

varying float vLifeT;      // 0 → fresh, 1 → dead
varying float vSpeed;

void main() {
  vLifeT = clamp(uAge / uLife, 0.0, 1.0);
  vSpeed = aSeed.w;

  // Ease-out expansion with a whisper of gravity for physicality.
  float travel = uSpread * vSpeed * (1.0 - pow(1.0 - vLifeT, 3.0));
  vec3 displaced = position + aSeed.xyz * travel;
  displaced.y -= vLifeT * vLifeT * 0.55 * vSpeed;

  vec4 mvPosition = modelViewMatrix * vec4(displaced, 1.0);
  gl_Position = projectionMatrix * mvPosition;

  float size = (1.0 - vLifeT) * (0.35 + 0.65 * vSpeed);
  gl_PointSize = size * uPointScale * (300.0 / -mvPosition.z);
}
