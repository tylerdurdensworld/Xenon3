// ─────────────────────────────────────────────────────────────────────────────
// neonGlow.glsl — shared GLSL chunk for every Xenon3 material.
// Function-only library (no uniform declarations) so it can be prepended to any
// vertex/fragment program without redefinition clashes.
// ─────────────────────────────────────────────────────────────────────────────

// Deterministic value-noise stack, cheap enough for integrated GPUs.
float xenHash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.1, 0.17, 0.13));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float xenNoise(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float n000 = xenHash(i);
  float n100 = xenHash(i + vec3(1.0, 0.0, 0.0));
  float n010 = xenHash(i + vec3(0.0, 1.0, 0.0));
  float n110 = xenHash(i + vec3(1.0, 1.0, 0.0));
  float n001 = xenHash(i + vec3(0.0, 0.0, 1.0));
  float n101 = xenHash(i + vec3(1.0, 0.0, 1.0));
  float n011 = xenHash(i + vec3(0.0, 1.0, 1.0));
  float n111 = xenHash(i + vec3(1.0, 1.0, 1.0));
  return mix(
    mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
    mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y),
    f.z
  );
}

// Xenon discharge palette: 0 → deep violet, 0.5 → electric cyan, 1 → hot magenta.
vec3 neonRamp(float t) {
  vec3 violet = vec3(0.482, 0.169, 1.000);
  vec3 cyan = vec3(0.000, 0.941, 1.000);
  vec3 magenta = vec3(1.000, 0.169, 0.839);
  vec3 low = mix(violet, cyan, smoothstep(0.0, 0.5, t));
  return mix(low, magenta, smoothstep(0.5, 1.0, t));
}

// Schlick-style fresnel rim — the "light trapped in glass" term.
float xenFresnel(vec3 normal, vec3 viewDir, float power) {
  return pow(1.0 - abs(dot(normalize(normal), normalize(viewDir))), power);
}

// Fine CRT-style scanline band sweeping along one axis.
float xenScanline(float coordinate, float time, float density, float softness) {
  float band = fract(coordinate * density - time);
  return smoothstep(0.0, softness, band) * smoothstep(1.0, 1.0 - softness, band);
}

// Tube flicker: mostly stable with occasional neon-dropout dips.
float xenFlicker(float time, float seed) {
  float n = xenNoise(vec3(time * 6.0, seed, seed * 0.37));
  float dip = step(0.93, n) * 0.55;
  return 1.0 - dip;
}
