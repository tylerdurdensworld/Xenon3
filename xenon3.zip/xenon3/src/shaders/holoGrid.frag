// ─────────────────────────────────────────────────────────────────────────────
// HoloGrid — fragment stage: the floating holographic floor.
// Concentric pulse rings + fine grid + a slow scan sweep, all additive.
// ─────────────────────────────────────────────────────────────────────────────

uniform float uTime;
uniform vec3 uColorA;   // primary neon (turn-colored)
uniform vec3 uColorB;   // secondary neon
uniform float uOpacity;

varying vec2 vUv;
varying vec3 vWorldPos;

float xenHash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.1, 0.17, 0.13));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float xenNoise(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float n000 = xenHash(i);
  float n100 = xenHash(i + vec3(1.0, 0.0, 0.0));
  float n010 = xenHash(i + vec3(0.0, 1.0, 0.0));
  float n110 = xenHash(i + vec3(1.0, 1.0, 0.0));
  float n001 = xenHash(i + vec3(0.0, 0.0, 1.0));
  float n101 = xenHash(i + vec3(1.0, 0.0, 1.0));
  float n011 = xenHash(i + vec3(0.0, 1.0, 1.0));
  float n111 = xenHash(i + vec3(1.0, 1.0, 1.0));
  return mix(
    mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
    mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y),
    f.z
  );
}

// Fine scan band sweeping along one axis.
float xenScanline(float coordinate, float time, float density, float softness) {
  float band = fract(coordinate * density - time);
  return smoothstep(0.0, softness, band) * smoothstep(1.0, 1.0 - softness, band);
}

void main() {
  vec2 centered = vUv - 0.5;
  float radius = length(centered);

  // Fine grid lines, anti-aliased via fwidth.
  vec2 gridUv = vUv * 24.0;
  vec2 grid = abs(fract(gridUv - 0.5) - 0.5) / fwidth(gridUv);
  float line = 1.0 - min(min(grid.x, grid.y), 1.0);

  // Radial sonar pulse expanding from the board center every few seconds.
  float pulse = smoothstep(0.02, 0.0, abs(radius - fract(uTime * 0.18) * 0.72) - 0.004);

  // Slow scan sweep across the floor.
  float sweep = xenScanline(vUv.y, uTime * 0.05, 1.0, 0.08);

  // Energy shimmer so the projection feels alive.
  float shimmer = 0.85 + 0.15 * xenNoise(vec3(vUv * 8.0, uTime * 0.6));

  // Fade to nothing at the plane edges — holograms don't have hard borders.
  float edgeFade = smoothstep(0.5, 0.18, radius);

  vec3 gridColor = mix(uColorA, uColorB, radius * 1.4);
  vec3 color = gridColor * (line * 0.55 + pulse * 1.6 + sweep * 0.35) * shimmer;
  float alpha = (line * 0.35 + pulse * 0.9 + sweep * 0.22) * edgeFade * uOpacity;

  gl_FragColor = vec4(color, alpha);
}
