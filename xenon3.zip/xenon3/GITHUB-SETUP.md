# Publish Xenon3 on GitHub — the simplest way (browser only, no PC)

Everything happens in your web browser. When you are done, the game is live
at `https://<your-username>.github.io/<repo-name>/` over HTTPS, so wallet
signing and the fullscreen PWA ("Add to Home Screen") both work.

You need exactly **one file** from this package: **`xenon3.zip`** (the zip
itself — do not unzip it).

---

## Step 1 — Create the repository

1. Go to **github.com** and sign in.
2. Top-right **+** → **New repository**.
3. Repository name: **anything you like** (e.g. `xenon3`).
   Asset paths are relative, so every name works. Your game URL becomes
   `https://<your-username>.github.io/<repo-name>/`.
4. Choose **Public** → **Create repository**.
   Leave all "initialize with README" checkboxes **unticked** — the repo
   must start empty.

## Step 2 — Upload the zip

1. On the empty repo page, click **"uploading an existing file"**
   (or **Add file → Upload files**).
2. Choose **`xenon3.zip`** from your downloads.
3. Press the green **Commit changes** button.

## Step 3 — Add the deployment workflow

1. In the repo: **Add file → Create new file**.
2. In the filename box, type exactly:
   ```
   .github/workflows/deploy-pages.yml
   ```
3. Paste the whole content of the file below (it is also inside the zip at
   `.github/workflows/deploy-pages.yml`):

```yaml
name: Deploy Xenon3 to GitHub Pages

on:
  push:
    paths:
      - 'xenon3.zip'
      - '.github/workflows/deploy-pages.yml'
  workflow_dispatch:

permissions:
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - uses: actions/checkout@v4

      - name: Unpack the game
        run: |
          test -f xenon3.zip
          rm -rf unpacked site
          mkdir -p unpacked
          unzip -q xenon3.zip -d unpacked
          test -d unpacked/xenon3/site
          cp -r unpacked/xenon3/site site
          touch site/.nojekyll
          test -f site/index.html

      - uses: actions/configure-pages@v5

      - uses: actions/upload-pages-artifact@v3
        with:
          path: site

      - id: deployment
        uses: actions/deploy-pages@v4
```

4. **Commit changes**.

## Step 4 — Point Pages at GitHub Actions (once)

1. Repo → **Settings** → **Pages** (left sidebar).
2. Under **Source**, pick **"GitHub Actions"**.

## Step 5 — Play

1. Open the **Actions** tab: "Deploy Xenon3 to GitHub Pages" runs for about
   a minute. A green checkmark means the site is live.
2. Visit **`https://<your-username>.github.io/<repo-name>/`** and play.
3. Optional: browser menu → **Add to Home Screen** for the fullscreen app.

## Updating the game

When a newer `xenon3.zip` arrives: **Add file → Upload files** → upload it
under the same name (it overwrites the old one) → Commit. The workflow
redeploys automatically.

## Connect your wallet

Open the WebQuid terminal → **WALLET → Export / Backup** → copy your
64-character key → paste it into Xenon3 → **IMPORT & CONNECT**
(the `0x` prefix is optional). Your key never leaves your device.

---

### Troubleshooting

| Symptom | Fix |
|---|---|
| Action fails with "Failed to create deployment" | Settings → Pages → Source must be **GitHub Actions** (Step 4) |
| Page 404s | Check the Actions tab for a green checkmark; the URL must include the repo name: `...github.io/<repo-name>/` |
| Workflow never runs | The zip must be named exactly `xenon3.zip` at the repository root |
| Wallet won't connect | Use `https://` (GitHub Pages already provides it) |
| Stale version shows | Hard-refresh the page or clear the browser cache |
