/* ─────────────────────────────────────────────────────────────────────────────
   Xenon3 service worker — offline-capable PWA shell.
   Strategy:
     • Precache the app shell ("/", manifest, icons) on install.
     • Navigations  → network-first, fall back to the cached shell when offline.
     • Hashed bundles (_next/static) and CDN fonts → cache-first (immutable).
     • Everything else (PeerJS signaling, WebRTC) → network-only, untouched.
   ───────────────────────────────────────────────────────────────────────────── */

// Bumped on every deploy (ship script stamps the date) so activate() purges
// stale shells. Hashed chunks are never deleted server-side, so an old shell
// keeps working until the tab reloads onto the fresh one.
const CACHE_VERSION = 'xenon3-20261015f';
const SHELL_CACHE = `${CACHE_VERSION}-shell`;
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;

// The game must run from any base path (project pages, bare domain, local
// folder), so every shell URL is derived from this worker's own scope
// instead of being hard-coded against the domain root.
const BASE = new URL('./', self.location.href).pathname;

const PRECACHE_URLS = [
  BASE,
  `${BASE}manifest.webmanifest`,
  `${BASE}icons/icon-192.png`,
  `${BASE}icons/icon-512.png`,
  `${BASE}icons/icon-maskable-512.png`,
  `${BASE}icons/apple-touch-icon.png`,
];

/** Hosts whose responses are safe to cache long-term (hashed or versioned). */
const CACHEABLE_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => !key.startsWith(CACHE_VERSION))
            .map((stale) => caches.delete(stale)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Only ever handle idempotent GETs; let everything else hit the network.
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Never intercept the signaling relay or any WebRTC traffic.
  if (url.hostname.includes('peerjs') || url.protocol.startsWith('ws')) return;

  // Navigations: network-first so players always get the freshest arena,
  // with the cached shell as the offline fallback.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(SHELL_CACHE).then((cache) => cache.put(BASE, copy));
          }
          return response;
        })
        .catch(async () => {
          const cached = await caches.match(BASE);
          return cached ?? Response.error();
        }),
    );
    return;
  }

  // Immutable build assets + font CDN: cache-first.
  const isStaticAsset =
    (url.origin === self.location.origin && url.pathname.includes('/_next/static/')) ||
    CACHEABLE_HOSTS.includes(url.hostname);

  if (isStaticAsset) {
    event.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ??
          fetch(request).then((response) => {
            if (response.ok || response.type === 'opaque') {
              const copy = response.clone();
              caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy));
            }
            return response;
          }),
      ),
    );
    return;
  }

  // Same-origin misc (icons, manifest): stale-while-revalidate.
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((cached) => {
        const refresh = fetch(request)
          .then((response) => {
            if (response.ok) {
              const copy = response.clone();
              caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy));
            }
            return response;
          })
          .catch(() => cached ?? Response.error());
        return cached ?? refresh;
      }),
    );
  }
});
